# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'formjUlTBL.ui'
##
## Created by: Qt User Interface Compiler version 6.7.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel,
    QLineEdit, QMainWindow, QPushButton, QScrollArea,
    QSizePolicy, QSpacerItem, QStackedWidget, QTabWidget,
    QVBoxLayout, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(820, 420)
        MainWindow.setMinimumSize(QSize(820, 420))
        MainWindow.setStyleSheet(u"")
        self.w_central = QWidget(MainWindow)
        self.w_central.setObjectName(u"w_central")
        self.w_central.setStyleSheet(u"background-color: rgb(65, 65, 65); \n"
"")
        self.verticalLayout = QVBoxLayout(self.w_central)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.f_cuerpo_up = QFrame(self.w_central)
        self.f_cuerpo_up.setObjectName(u"f_cuerpo_up")
        self.f_cuerpo_up.setMaximumSize(QSize(16777215, 40))
        self.f_cuerpo_up.setStyleSheet(u"background-color: rgb(45, 45, 45); \n"
"")
        self.f_cuerpo_up.setFrameShape(QFrame.Shape.NoFrame)
        self.horizontalLayout = QHBoxLayout(self.f_cuerpo_up)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.f_logo = QFrame(self.f_cuerpo_up)
        self.f_logo.setObjectName(u"f_logo")
        self.f_logo.setMaximumSize(QSize(50, 40))
        self.f_logo.setStyleSheet(u"background-color: rgb(170, 85, 255)")
        self.f_logo.setFrameShape(QFrame.Shape.NoFrame)
        self.horizontalLayout_3 = QHBoxLayout(self.f_logo)
        self.horizontalLayout_3.setSpacing(0)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.b_logo = QPushButton(self.f_logo)
        self.b_logo.setObjectName(u"b_logo")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.b_logo.sizePolicy().hasHeightForWidth())
        self.b_logo.setSizePolicy(sizePolicy)
        self.b_logo.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: 0px solid;\n"
"opacity: 0.5;")
        icon = QIcon()
        icon.addFile(u"../VS Code/PROYECTO QT PY/APP/images/images/PyDracula.png", QSize(), QIcon.Normal, QIcon.Off)
        self.b_logo.setIcon(icon)
        self.b_logo.setIconSize(QSize(32, 32))
        self.b_logo.setCheckable(True)

        self.horizontalLayout_3.addWidget(self.b_logo)


        self.horizontalLayout.addWidget(self.f_logo)

        self.f_barra = QFrame(self.f_cuerpo_up)
        self.f_barra.setObjectName(u"f_barra")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.f_barra.sizePolicy().hasHeightForWidth())
        self.f_barra.setSizePolicy(sizePolicy1)
        self.f_barra.setMaximumSize(QSize(4000, 40))
        self.f_barra.setFrameShape(QFrame.Shape.NoFrame)
        self.horizontalLayout_5 = QHBoxLayout(self.f_barra)
        self.horizontalLayout_5.setSpacing(0)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.horizontalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.horizontalSpacer_5 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_5.addItem(self.horizontalSpacer_5)

        self.f_perfil = QFrame(self.f_barra)
        self.f_perfil.setObjectName(u"f_perfil")
        self.f_perfil.setMaximumSize(QSize(60, 40))
        self.f_perfil.setFrameShape(QFrame.Shape.NoFrame)
        self.horizontalLayout_6 = QHBoxLayout(self.f_perfil)
        self.horizontalLayout_6.setSpacing(0)
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.horizontalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.b_perfil = QPushButton(self.f_perfil)
        self.b_perfil.setObjectName(u"b_perfil")
        self.b_perfil.setMinimumSize(QSize(40, 40))
        self.b_perfil.setMaximumSize(QSize(40, 40))
        self.b_perfil.setStyleSheet(u"QPushButton{\n"
"	color: rgb(255, 255, 255);\n"
"	background-color: rgb(45, 45, 45);\n"
"	border: 0px soild\n"
"}\n"
"\n"
"QPushButton:hover{\n"
"	background-color: rgb(170, 85, 255);\n"
"}\n"
"")
        icon1 = QIcon()
        icon1.addFile(u"../VS Code/PROYECTO QT PY/APP/images/icons/cil-people.png", QSize(), QIcon.Normal, QIcon.Off)
        self.b_perfil.setIcon(icon1)

        self.horizontalLayout_6.addWidget(self.b_perfil)


        self.horizontalLayout_5.addWidget(self.f_perfil, 0, Qt.AlignmentFlag.AlignRight)


        self.horizontalLayout.addWidget(self.f_barra)


        self.verticalLayout.addWidget(self.f_cuerpo_up)

        self.f_cuerpo_dawn = QFrame(self.w_central)
        self.f_cuerpo_dawn.setObjectName(u"f_cuerpo_dawn")
        self.f_cuerpo_dawn.setFrameShape(QFrame.Shape.NoFrame)
        self.horizontalLayout_2 = QHBoxLayout(self.f_cuerpo_dawn)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.f_m_icon = QFrame(self.f_cuerpo_dawn)
        self.f_m_icon.setObjectName(u"f_m_icon")
        self.f_m_icon.setMinimumSize(QSize(50, 0))
        self.f_m_icon.setMaximumSize(QSize(50, 4000))
        self.f_m_icon.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.f_m_icon.setStyleSheet(u"background-color: rgb(45, 45, 45); ")
        self.f_m_icon.setFrameShape(QFrame.Shape.NoFrame)
        self.verticalLayout_2 = QVBoxLayout(self.f_m_icon)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.b_encuesta = QPushButton(self.f_m_icon)
        self.b_encuesta.setObjectName(u"b_encuesta")
        self.b_encuesta.setMinimumSize(QSize(50, 40))
        self.b_encuesta.setStyleSheet(u"QPushButton{\n"
"	color: rgb(255, 255, 255);\n"
"	background-color: rgb(45, 45, 45);\n"
"	border: 0px soild\n"
"}\n"
"QPushButton:hover{\n"
"	background-color: rgb(170, 85, 255);\n"
"}\n"
"")
        icon2 = QIcon()
        icon2.addFile(u"../VS Code/PROYECTO QT PY/APP/images/icons/cil-notes.png", QSize(), QIcon.Normal, QIcon.Off)
        self.b_encuesta.setIcon(icon2)
        self.b_encuesta.setCheckable(True)
        self.b_encuesta.setAutoExclusive(True)
        self.b_encuesta.setAutoDefault(False)

        self.verticalLayout_2.addWidget(self.b_encuesta)

        self.b_shear = QPushButton(self.f_m_icon)
        self.b_shear.setObjectName(u"b_shear")
        self.b_shear.setMinimumSize(QSize(50, 40))
        self.b_shear.setMouseTracking(True)
        self.b_shear.setStyleSheet(u"QPushButton{\n"
"	color: rgb(255, 255, 255);\n"
"	background-color: rgb(45, 45, 45);\n"
"	border: 0px soild\n"
"}\n"
"QPushButton:hover{\n"
"	background-color: rgb(170, 85, 255);\n"
"}\n"
"")
        icon3 = QIcon()
        icon3.addFile(u"../VS Code/PROYECTO QT PY/APP/images/icons/cil-magnifying-glass.png", QSize(), QIcon.Normal, QIcon.Off)
        self.b_shear.setIcon(icon3)
        self.b_shear.setCheckable(True)
        self.b_shear.setAutoExclusive(True)

        self.verticalLayout_2.addWidget(self.b_shear)

        self.b_stats = QPushButton(self.f_m_icon)
        self.b_stats.setObjectName(u"b_stats")
        self.b_stats.setMinimumSize(QSize(50, 40))
        self.b_stats.setStyleSheet(u"QPushButton{\n"
"	color: rgb(255, 255, 255);\n"
"	background-color: rgb(45, 45, 45);\n"
"	border: 0px soild\n"
"}\n"
"QPushButton:hover{\n"
"	background-color: rgb(170, 85, 255);\n"
"}\n"
"")
        icon4 = QIcon()
        icon4.addFile(u"../VS Code/PROYECTO QT PY/APP/images/icons/cil-chart-line.png", QSize(), QIcon.Normal, QIcon.Off)
        self.b_stats.setIcon(icon4)
        self.b_stats.setCheckable(True)
        self.b_stats.setAutoExclusive(True)

        self.verticalLayout_2.addWidget(self.b_stats)

        self.verticalSpacer = QSpacerItem(20, 257, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_2.addItem(self.verticalSpacer)

        self.b_config = QPushButton(self.f_m_icon)
        self.b_config.setObjectName(u"b_config")
        self.b_config.setMinimumSize(QSize(50, 40))
        self.b_config.setStyleSheet(u"QPushButton{\n"
"	color: rgb(255, 255, 255);\n"
"	background-color: rgb(45, 45, 45);\n"
"	border: 0px soild\n"
"}\n"
"\n"
"QPushButton:hover{\n"
"	background-color: rgb(170, 85, 255);\n"
"}\n"
"")
        icon5 = QIcon()
        icon5.addFile(u"../VS Code/PROYECTO QT PY/APP/images/icons/cil-settings.png", QSize(), QIcon.Normal, QIcon.Off)
        self.b_config.setIcon(icon5)
        self.b_config.setCheckable(True)
        self.b_config.setAutoExclusive(True)

        self.verticalLayout_2.addWidget(self.b_config)


        self.horizontalLayout_2.addWidget(self.f_m_icon)

        self.f_ventanas = QFrame(self.f_cuerpo_dawn)
        self.f_ventanas.setObjectName(u"f_ventanas")
        sizePolicy1.setHeightForWidth(self.f_ventanas.sizePolicy().hasHeightForWidth())
        self.f_ventanas.setSizePolicy(sizePolicy1)
        self.f_ventanas.setFrameShape(QFrame.Shape.NoFrame)
        self.verticalLayout_4 = QVBoxLayout(self.f_ventanas)
        self.verticalLayout_4.setSpacing(0)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.stackedWidget = QStackedWidget(self.f_ventanas)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.stackedWidget.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.pag_0 = QWidget()
        self.pag_0.setObjectName(u"pag_0")
        self.horizontalLayout_10 = QHBoxLayout(self.pag_0)
        self.horizontalLayout_10.setSpacing(0)
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.horizontalLayout_10.setContentsMargins(0, 0, 0, 0)
        self.f_pag0_inicio = QFrame(self.pag_0)
        self.f_pag0_inicio.setObjectName(u"f_pag0_inicio")
        self.f_pag0_inicio.setFrameShape(QFrame.Shape.NoFrame)
        self.verticalLayout_6 = QVBoxLayout(self.f_pag0_inicio)
        self.verticalLayout_6.setSpacing(0)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.label = QLabel(self.f_pag0_inicio)
        self.label.setObjectName(u"label")
        self.label.setMinimumSize(QSize(32, 32))
        self.label.setPixmap(QPixmap(u"../VS Code/PROYECTO QT PY/APP/images/images/ugma.png"))

        self.verticalLayout_6.addWidget(self.label, 0, Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignVCenter)


        self.horizontalLayout_10.addWidget(self.f_pag0_inicio)

        self.stackedWidget.addWidget(self.pag_0)
        self.pag_4 = QWidget()
        self.pag_4.setObjectName(u"pag_4")
        self.horizontalLayout_4 = QHBoxLayout(self.pag_4)
        self.horizontalLayout_4.setSpacing(0)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.f_pag4_shear = QFrame(self.pag_4)
        self.f_pag4_shear.setObjectName(u"f_pag4_shear")
        self.f_pag4_shear.setFrameShape(QFrame.Shape.NoFrame)
        self.f_pag4_shear.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_3 = QVBoxLayout(self.f_pag4_shear)
        self.verticalLayout_3.setSpacing(6)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 9, 0, 9)
        self.f_shear_up = QFrame(self.f_pag4_shear)
        self.f_shear_up.setObjectName(u"f_shear_up")
        self.f_shear_up.setMaximumSize(QSize(16777215, 40))
        self.f_shear_up.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.f_shear_up.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_shear_up.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_11 = QHBoxLayout(self.f_shear_up)
        self.horizontalLayout_11.setSpacing(0)
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.horizontalLayout_11.setContentsMargins(0, 0, 0, 0)
        self.b_shear_2 = QPushButton(self.f_shear_up)
        self.b_shear_2.setObjectName(u"b_shear_2")
        self.b_shear_2.setMinimumSize(QSize(50, 35))
        self.b_shear_2.setMaximumSize(QSize(50, 35))
        self.b_shear_2.setMouseTracking(True)
        self.b_shear_2.setStyleSheet(u"/*QPushButton{\n"
"	color: rgb(255, 255, 255);\n"
"	background-color: rgb(45, 45, 45);\n"
"	border: 0px soild\n"
"}*/\n"
"QPushButton:hover{\n"
"	background-color: rgb(170, 85, 255);\n"
"}\n"
"")
        self.b_shear_2.setIcon(icon3)
        self.b_shear_2.setCheckable(False)
        self.b_shear_2.setAutoExclusive(False)

        self.horizontalLayout_11.addWidget(self.b_shear_2)

        self.lineEdit = QLineEdit(self.f_shear_up)
        self.lineEdit.setObjectName(u"lineEdit")
        self.lineEdit.setMinimumSize(QSize(300, 35))
        self.lineEdit.setMaximumSize(QSize(400, 35))
        self.lineEdit.setEchoMode(QLineEdit.EchoMode.Normal)
        self.lineEdit.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lineEdit.setCursorMoveStyle(Qt.CursorMoveStyle.LogicalMoveStyle)

        self.horizontalLayout_11.addWidget(self.lineEdit)


        self.verticalLayout_3.addWidget(self.f_shear_up, 0, Qt.AlignmentFlag.AlignHCenter)

        self.f_shear_dawn = QFrame(self.f_pag4_shear)
        self.f_shear_dawn.setObjectName(u"f_shear_dawn")
        self.f_shear_dawn.setFrameShape(QFrame.Shape.NoFrame)
        self.f_shear_dawn.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_5 = QVBoxLayout(self.f_shear_dawn)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.scrollArea = QScrollArea(self.f_shear_dawn)
        self.scrollArea.setObjectName(u"scrollArea")
        self.scrollArea.setWidgetResizable(True)
        self.scrollAreaContents = QWidget()
        self.scrollAreaContents.setObjectName(u"scrollAreaContents")
        self.scrollAreaContents.setGeometry(QRect(0, 0, 750, 299))
        self.verticalLayout_10 = QVBoxLayout(self.scrollAreaContents)
        self.verticalLayout_10.setSpacing(0)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.verticalLayout_10.setContentsMargins(0, -1, 0, -1)
        self.verticalSpacer_2 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_10.addItem(self.verticalSpacer_2)

        self.scrollArea.setWidget(self.scrollAreaContents)

        self.verticalLayout_5.addWidget(self.scrollArea)


        self.verticalLayout_3.addWidget(self.f_shear_dawn)


        self.horizontalLayout_4.addWidget(self.f_pag4_shear)

        self.stackedWidget.addWidget(self.pag_4)
        self.pag_3 = QWidget()
        self.pag_3.setObjectName(u"pag_3")
        self.horizontalLayout_9 = QHBoxLayout(self.pag_3)
        self.horizontalLayout_9.setSpacing(0)
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.horizontalLayout_9.setContentsMargins(0, 0, 0, 0)
        self.f_pag3_config = QFrame(self.pag_3)
        self.f_pag3_config.setObjectName(u"f_pag3_config")
        self.f_pag3_config.setFrameShape(QFrame.Shape.NoFrame)
        self.f_pag3_config.setFrameShadow(QFrame.Shadow.Raised)
        self.label_4 = QLabel(self.f_pag3_config)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(40, 210, 691, 361))
        self.label_4.setMinimumSize(QSize(32, 32))
        self.label_4.setPixmap(QPixmap(u"../VS Code/PROYECTO QT PY/APP/images/images/ugma.png"))

        self.horizontalLayout_9.addWidget(self.f_pag3_config)

        self.stackedWidget.addWidget(self.pag_3)
        self.pag_2 = QWidget()
        self.pag_2.setObjectName(u"pag_2")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Maximum)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.pag_2.sizePolicy().hasHeightForWidth())
        self.pag_2.setSizePolicy(sizePolicy2)
        self.horizontalLayout_7 = QHBoxLayout(self.pag_2)
        self.horizontalLayout_7.setSpacing(0)
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.horizontalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.f_pag2_stats = QFrame(self.pag_2)
        self.f_pag2_stats.setObjectName(u"f_pag2_stats")
        self.f_pag2_stats.setFrameShape(QFrame.Shape.NoFrame)
        self.f_pag2_stats.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_13 = QHBoxLayout(self.f_pag2_stats)
        self.horizontalLayout_13.setObjectName(u"horizontalLayout_13")
        self.tabWidget = QTabWidget(self.f_pag2_stats)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setTabsClosable(True)

        self.horizontalLayout_13.addWidget(self.tabWidget)


        self.horizontalLayout_7.addWidget(self.f_pag2_stats)

        self.stackedWidget.addWidget(self.pag_2)
        self.pag_1 = QWidget()
        self.pag_1.setObjectName(u"pag_1")
        self.horizontalLayout_8 = QHBoxLayout(self.pag_1)
        self.horizontalLayout_8.setSpacing(0)
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.horizontalLayout_8.setContentsMargins(0, 0, 0, 0)
        self.f_pag1_encuesta = QFrame(self.pag_1)
        self.f_pag1_encuesta.setObjectName(u"f_pag1_encuesta")
        self.f_pag1_encuesta.setFrameShape(QFrame.Shape.NoFrame)
        self.f_pag1_encuesta.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_12 = QHBoxLayout(self.f_pag1_encuesta)
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.stackedWidget_2 = QStackedWidget(self.f_pag1_encuesta)
        self.stackedWidget_2.setObjectName(u"stackedWidget_2")
        self.e_pag_0 = QWidget()
        self.e_pag_0.setObjectName(u"e_pag_0")
        self.horizontalLayout_15 = QHBoxLayout(self.e_pag_0)
        self.horizontalLayout_15.setObjectName(u"horizontalLayout_15")
        self.b_edit_encuesta = QPushButton(self.e_pag_0)
        self.b_edit_encuesta.setObjectName(u"b_edit_encuesta")
        self.b_edit_encuesta.setStyleSheet(u"QPushButton{\n"
"}")
        self.b_edit_encuesta.setCheckable(True)

        self.horizontalLayout_15.addWidget(self.b_edit_encuesta)

        self.b_enviar_encuesta = QPushButton(self.e_pag_0)
        self.b_enviar_encuesta.setObjectName(u"b_enviar_encuesta")
        self.b_enviar_encuesta.setCheckable(True)

        self.horizontalLayout_15.addWidget(self.b_enviar_encuesta)

        self.stackedWidget_2.addWidget(self.e_pag_0)
        self.e_pag_1 = QWidget()
        self.e_pag_1.setObjectName(u"e_pag_1")
        self.verticalLayout_7 = QVBoxLayout(self.e_pag_1)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.b_cancelar_encuesta = QPushButton(self.e_pag_1)
        self.b_cancelar_encuesta.setObjectName(u"b_cancelar_encuesta")

        self.verticalLayout_7.addWidget(self.b_cancelar_encuesta)

        self.b_guardar_encuesta = QPushButton(self.e_pag_1)
        self.b_guardar_encuesta.setObjectName(u"b_guardar_encuesta")

        self.verticalLayout_7.addWidget(self.b_guardar_encuesta)

        self.f_edit_up = QFrame(self.e_pag_1)
        self.f_edit_up.setObjectName(u"f_edit_up")
        self.f_edit_up.setMinimumSize(QSize(0, 60))
        self.f_edit_up.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_edit_up.setFrameShadow(QFrame.Shadow.Raised)
        self.b_categoria = QPushButton(self.f_edit_up)
        self.b_categoria.setObjectName(u"b_categoria")
        self.b_categoria.setGeometry(QRect(80, 10, 75, 24))
        self.pushButton_10 = QPushButton(self.f_edit_up)
        self.pushButton_10.setObjectName(u"pushButton_10")
        self.pushButton_10.setGeometry(QRect(210, 10, 75, 24))
        self.pushButton_11 = QPushButton(self.f_edit_up)
        self.pushButton_11.setObjectName(u"pushButton_11")
        self.pushButton_11.setGeometry(QRect(340, 10, 75, 24))
        self.pushButton_12 = QPushButton(self.f_edit_up)
        self.pushButton_12.setObjectName(u"pushButton_12")
        self.pushButton_12.setGeometry(QRect(460, 10, 75, 24))
        self.pushButton_15 = QPushButton(self.f_edit_up)
        self.pushButton_15.setObjectName(u"pushButton_15")
        self.pushButton_15.setGeometry(QRect(690, 10, 31, 31))
        self.pushButton_16 = QPushButton(self.f_edit_up)
        self.pushButton_16.setObjectName(u"pushButton_16")
        self.pushButton_16.setGeometry(QRect(650, 10, 31, 31))

        self.verticalLayout_7.addWidget(self.f_edit_up)

        self.f_edit_dawn = QFrame(self.e_pag_1)
        self.f_edit_dawn.setObjectName(u"f_edit_dawn")
        self.f_edit_dawn.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_edit_dawn.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_14 = QHBoxLayout(self.f_edit_dawn)
        self.horizontalLayout_14.setObjectName(u"horizontalLayout_14")
        self.stackedWidget_3 = QStackedWidget(self.f_edit_dawn)
        self.stackedWidget_3.setObjectName(u"stackedWidget_3")
        self.page_3 = QWidget()
        self.page_3.setObjectName(u"page_3")
        self.verticalLayout_8 = QVBoxLayout(self.page_3)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.lineEdit_2 = QLineEdit(self.page_3)
        self.lineEdit_2.setObjectName(u"lineEdit_2")

        self.verticalLayout_8.addWidget(self.lineEdit_2)

        self.lineEdit_3 = QLineEdit(self.page_3)
        self.lineEdit_3.setObjectName(u"lineEdit_3")

        self.verticalLayout_8.addWidget(self.lineEdit_3)

        self.lineEdit_4 = QLineEdit(self.page_3)
        self.lineEdit_4.setObjectName(u"lineEdit_4")

        self.verticalLayout_8.addWidget(self.lineEdit_4)

        self.lineEdit_5 = QLineEdit(self.page_3)
        self.lineEdit_5.setObjectName(u"lineEdit_5")

        self.verticalLayout_8.addWidget(self.lineEdit_5)

        self.stackedWidget_3.addWidget(self.page_3)
        self.page_4 = QWidget()
        self.page_4.setObjectName(u"page_4")
        self.stackedWidget_3.addWidget(self.page_4)

        self.horizontalLayout_14.addWidget(self.stackedWidget_3)


        self.verticalLayout_7.addWidget(self.f_edit_dawn)

        self.stackedWidget_2.addWidget(self.e_pag_1)

        self.horizontalLayout_12.addWidget(self.stackedWidget_2)


        self.horizontalLayout_8.addWidget(self.f_pag1_encuesta)

        self.stackedWidget.addWidget(self.pag_1)

        self.verticalLayout_4.addWidget(self.stackedWidget)


        self.horizontalLayout_2.addWidget(self.f_ventanas)


        self.verticalLayout.addWidget(self.f_cuerpo_dawn)

        MainWindow.setCentralWidget(self.w_central)

        self.retranslateUi(MainWindow)

        self.stackedWidget.setCurrentIndex(0)
        self.tabWidget.setCurrentIndex(-1)
        self.stackedWidget_2.setCurrentIndex(0)
        self.stackedWidget_3.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.b_logo.setText("")
        self.b_perfil.setText("")
        self.b_encuesta.setText("")
        self.b_stats.setText("")
        self.b_config.setText("")
        self.label.setText("")
        self.lineEdit.setText(QCoreApplication.translate("MainWindow", u"....", None))
        self.label_4.setText("")
        self.b_edit_encuesta.setText(QCoreApplication.translate("MainWindow", u"EDITAR ENCUESTAS", None))
        self.b_enviar_encuesta.setText(QCoreApplication.translate("MainWindow", u"ENVIAR ENCUESTAS", None))
        self.b_cancelar_encuesta.setText(QCoreApplication.translate("MainWindow", u"X", None))
        self.b_guardar_encuesta.setText(QCoreApplication.translate("MainWindow", u"G", None))
        self.b_categoria.setText(QCoreApplication.translate("MainWindow", u"cat 1", None))
        self.pushButton_10.setText(QCoreApplication.translate("MainWindow", u"cat2", None))
        self.pushButton_11.setText(QCoreApplication.translate("MainWindow", u"cat 3", None))
        self.pushButton_12.setText(QCoreApplication.translate("MainWindow", u"cat 4", None))
        self.pushButton_15.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_16.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.lineEdit_2.setText(QCoreApplication.translate("MainWindow", u"pregunta 1", None))
        self.lineEdit_3.setText(QCoreApplication.translate("MainWindow", u"pregunta 2", None))
        self.lineEdit_4.setText(QCoreApplication.translate("MainWindow", u"pregunta 3", None))
        self.lineEdit_5.setText(QCoreApplication.translate("MainWindow", u"pregunta 4", None))
    # retranslateUi

