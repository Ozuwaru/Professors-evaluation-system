import sys
from PySide6.QtWidgets import QApplication, QGraphicsItem, QGraphicsView, QGraphicsScene
from PySide6.QtCharts import QChart, QBarSeries, QBarSet, QChartView, QPieSeries, QPieSlice, QBarCategoryAxis, QValueAxis
from PySide6.QtCore import Qt, QPointF, QRectF
from PySide6.QtGui import QPainter, QPainterPath, QFontMetricsF, QPen, QColor

class Callout(QGraphicsItem):
    def __init__(self, chart):
        super().__init__()
        self.chart = chart
        self.text = ""
        self.anchor = QPointF()
        self.rect = QRectF()

    def set_text(self, text):
        self.text = text
        metrics = QFontMetricsF(self.chart.font())
        self.rect = metrics.boundingRect(QRectF(0, 0, 150, 50), Qt.AlignLeft, self.text)
        self.rect.translate(5, 5)
        self.prepareGeometryChange()
        self.update()

    def set_anchor(self, point):
        self.anchor = point
        self.prepareGeometryChange()
        self.update()

    def boundingRect(self):
        return self.rect.adjusted(-5, -5, 5, 5)

    def paint(self, painter, option, widget):
        path = QPainterPath()
        path.addRoundedRect(self.rect, 5, 5)
        painter.setBrush(Qt.white)
        painter.setPen(Qt.black)
        painter.drawPath(path)
        painter.drawText(self.rect, self.text)

    def updateGeometry(self):
        self.prepareGeometryChange()
        self.update()

class View(QGraphicsView):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setScene(QGraphicsScene(self))
        self.setDragMode(QGraphicsView.NoDrag)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        # Crear el gráfico de barras
        self._chart = QChart()
        self._chart.setMinimumSize(640, 480)
        self._chart.setTitle("Hover over the bars to show callout.")
        self._chart.setTheme(QChart.ChartThemeDark)  # Establecer tema oscuro
        self._chart.setAnimationOptions(QChart.AllAnimations)  # Habilitar animaciones

        # Crear series de barras
        set0 = QBarSet("Set 0")
        set0 << 1 << 2 << 3 << 4 << 5 << 6
        set0.setColor(QColor("purple"))

        series = QBarSeries()
        series.append(set0)
        self._chart.addSeries(series)

        # Añadir categorías al eje
        categories = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"]
        axisX = QBarCategoryAxis()
        axisX.append(categories)
        axisY = QValueAxis()
        axisY.setRange(0, 7)
        self._chart.setAxisX(axisX, series)
        self._chart.setAxisY(axisY, series)

        # Agregar el gráfico a la escena
        self.scene().addItem(self._chart)

        # Crear un callout y personalizarlo
        self.callouts = []
        for i in range(len(categories)):
            callout = Callout(self._chart)
            callout.set_text(f"Value: {set0.at(i)}")
            callout.set_anchor(QPointF(i + 0.5, set0.at(i)))  # Ajustar la posición del callout
            self.callouts.append(callout)
            self.scene().addItem(callout)

        # Crear el gráfico de tarta
        self.pie_chart = QChart()
        self.pie_chart.setMinimumSize(640, 480)
        self.pie_chart.setTitle("Click on a slice to drilldown.")
        self.pie_chart.setTheme(QChart.ChartThemeDark)  # Establecer tema oscuro
        self.pie_chart.setAnimationOptions(QChart.AllAnimations)  # Habilitar animaciones

        self.main_series = QPieSeries()
        self.main_series.append("Slice 1", 10)
        self.main_series.append("Slice 2", 20)
        self.main_series.append("Slice 3", 30)

        # Configurar drilldown
        for slice in self.main_series.slices():
            slice.clicked.connect(self.drilldownSlice)

        self.pie_chart.addSeries(self.main_series)
        self.pie_chart.setPos(650, 0)  # Colocar el gráfico de tarta a la derecha del gráfico de barras
        self.scene().addItem(self.pie_chart)

    def drilldownSlice(self):
        slice = self.sender()
        drilldown_series = QPieSeries()
        drilldown_series.append("Subslice 1", slice.value() / 2)
        drilldown_series.append("Subslice 2", slice.value() / 2)
        drilldown_series.slices()[0].clicked.connect(self.restoreMainSeries)
        drilldown_series.slices()[1].clicked.connect(self.restoreMainSeries)
        self.pie_chart.removeAllSeries()
        self.pie_chart.addSeries(drilldown_series)

    def restoreMainSeries(self):
        self.pie_chart.removeAllSeries()
        self.pie_chart.addSeries(self.main_series)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    view = View()
    view.show()
    sys.exit(app.exec())
