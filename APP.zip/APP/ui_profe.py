# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ui_profeRiLxpx.ui'
##
## Created by: Qt User Interface Compiler version 6.7.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel,
    QSizePolicy, QSpacerItem, QTabWidget, QVBoxLayout,
    QWidget)

class Ui_f_profe(object):
    def setupUi(self, f_profe):
        if not f_profe.objectName():
            f_profe.setObjectName(u"f_profe")
        f_profe.resize(795, 426)
        self.verticalLayout = QVBoxLayout(f_profe)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.f_up = QFrame(f_profe)
        self.f_up.setObjectName(u"f_up")
        self.f_up.setMinimumSize(QSize(0, 40))
        self.f_up.setMaximumSize(QSize(16777215, 60))
        self.f_up.setFrameShape(QFrame.Shape.NoFrame)
        self.f_up.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_5 = QHBoxLayout(self.f_up)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.escuela_profe = QLabel(self.f_up)
        self.escuela_profe.setObjectName(u"escuela_profe")

        self.horizontalLayout_5.addWidget(self.escuela_profe)

        self.horizontalSpacer_3 = QSpacerItem(568, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_5.addItem(self.horizontalSpacer_3)

        self.nombre_profe = QLabel(self.f_up)
        self.nombre_profe.setObjectName(u"nombre_profe")

        self.horizontalLayout_5.addWidget(self.nombre_profe)

        self.horizontalSpacer_7 = QSpacerItem(10, 20, QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_5.addItem(self.horizontalSpacer_7)

        # self.perfil_profe = QLabel(self.f_up)
        # self.perfil_profe.setObjectName(u"perfil_profe")

        # self.horizontalLayout_5.addWidget(self.perfil_profe)


        self.verticalLayout.addWidget(self.f_up)

        self.f_cuerpo = QFrame(f_profe)
        self.f_cuerpo.setObjectName(u"f_cuerpo")
        self.f_cuerpo.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_cuerpo.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout = QHBoxLayout(self.f_cuerpo)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.f_graf_barra = QFrame(self.f_cuerpo)
        self.f_graf_barra.setObjectName(u"f_graf_barra")
        self.f_graf_barra.setFrameShape(QFrame.Shape.NoFrame)
        self.f_graf_barra.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_3 = QHBoxLayout(self.f_graf_barra)
        self.horizontalLayout_3.setSpacing(0)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.tab_graf_barra = QTabWidget(self.f_graf_barra)
        self.tab_graf_barra.setObjectName(u"tab_graf_barra")

        self.horizontalLayout_3.addWidget(self.tab_graf_barra)


        self.horizontalLayout.addWidget(self.f_graf_barra)

        self.f_graf_linea = QFrame(self.f_cuerpo)
        self.f_graf_linea.setObjectName(u"f_graf_linea")
        self.f_graf_linea.setFrameShape(QFrame.Shape.NoFrame)
        self.f_graf_linea.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.f_graf_linea)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.tab_graf_linea = QTabWidget(self.f_graf_linea)
        self.tab_graf_linea.setObjectName(u"tab_graf_linea")

        self.horizontalLayout_2.addWidget(self.tab_graf_linea)


        self.horizontalLayout.addWidget(self.f_graf_linea)


        self.verticalLayout.addWidget(self.f_cuerpo)

        self.f_dawn = QFrame(f_profe)
        self.f_dawn.setObjectName(u"f_dawn")
        self.f_dawn.setMinimumSize(QSize(0, 30))
        self.f_dawn.setMaximumSize(QSize(16777215, 35))
        self.f_dawn.setFrameShape(QFrame.Shape.NoFrame)
        self.f_dawn.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_4 = QHBoxLayout(self.f_dawn)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalSpacer = QSpacerItem(256, 12, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer)

        self.info_0 = QLabel(self.f_dawn)
        self.info_0.setObjectName(u"info_0")

        self.horizontalLayout_4.addWidget(self.info_0)

        self.horizontalSpacer_4 = QSpacerItem(256, 12, QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_4)

        self.info_1 = QLabel(self.f_dawn)
        self.info_1.setObjectName(u"info_1")

        self.horizontalLayout_4.addWidget(self.info_1)

        self.horizontalSpacer_5 = QSpacerItem(256, 12, QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_5)

        self.info_2 = QLabel(self.f_dawn)
        self.info_2.setObjectName(u"info_2")

        self.horizontalLayout_4.addWidget(self.info_2)

        self.horizontalSpacer_6 = QSpacerItem(256, 12, QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_6)

        self.info_3 = QLabel(self.f_dawn)
        self.info_3.setObjectName(u"info_3")

        self.horizontalLayout_4.addWidget(self.info_3)

        self.horizontalSpacer_2 = QSpacerItem(256, 12, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_2)


        self.verticalLayout.addWidget(self.f_dawn)

        self.info_4 = QLabel(self.f_dawn)
        self.info_4.setObjectName(u"info_4")

        self.horizontalLayout_4.addWidget(self.info_4)

        self.horizontalSpacer_2 = QSpacerItem(256, 12, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_2)


        self.verticalLayout.addWidget(self.f_dawn)
        
        self.retranslateUi(f_profe)

        self.tab_graf_barra.setCurrentIndex(-1)
        self.tab_graf_linea.setCurrentIndex(-1)


        QMetaObject.connectSlotsByName(f_profe)
    # setupUi

    def retranslateUi(self, f_profe):
        f_profe.setWindowTitle(QCoreApplication.translate("f_profe", u"Frame", None))
        self.escuela_profe.setText(QCoreApplication.translate("f_profe", u"escuela", None))
        self.nombre_profe.setText(QCoreApplication.translate("f_profe", u"nombre_profe", None))
        # self.perfil_profe.setText(QCoreApplication.translate("f_profe", u"perfil_prfe", None))
        self.info_0.setText(QCoreApplication.translate("f_profe", u"dato_1", None))
        self.info_1.setText(QCoreApplication.translate("f_profe", u"dato_2", None))
        self.info_2.setText(QCoreApplication.translate("f_profe", u"dato_2", None))
        self.info_3.setText(QCoreApplication.translate("f_profe", u"dato_3", None))
        self.info_4.setText(QCoreApplication.translate("f_profe", u"dato_4", None))
    # retranslateUi

