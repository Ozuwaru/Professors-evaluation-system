from PySide6.QtWidgets import QApplication, QMainWindow, QFrame, QWidget
from PySide6.QtCore import Qt
from PySide6.QtGui import QScreen
from ui_form import Ui_MainWindow 
from ui_perfil import Ui_f_shear_profe
from ui_profe import Ui_f_profe
from funciones import *
from Bot_mail import *

# from ui_user import Ui_Frame

class App(QMainWindow):
    def __init__(self):
        super(App, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        
        # CONECCIONES DEL MENU PRINCIPAL
        self.ui.b_logo.clicked.connect(self.mostrarPaginaInicio)
        self.ui.b_encuesta.toggled.connect(self.mostrarPaginaEncuesta)
        self.ui.b_stats.toggled.connect(self.mostrarPaginaEstadisticas)
        self.ui.b_shear.toggled.connect(self.mostrarPaginaBusqueda)
        self.ui.b_config.toggled.connect(self.mostrarPaginaConfiguracion)
        
        
        self.ui.b_enviar_encuesta.toggled.connect(self.activarBot)
        self.ui.b_edit_encuesta.toggled.connect(self.mostrarPaginaEdicion)
        
        #self.ui.b_perfil.toggled.connect(self.mostrarPaginaConfiguracion)
        
        # CONECCIONES DE LA PAGINA DE BUSQUEDA
        self.ui.b_shear_2.clicked.connect(self.resultadoBusqueda)
        
        # CONECCIONES DE LA PAGINA DE ESTADISTICAS
        # self.ui.b_.clicked.connect(self.nuevaEstadisticas)
        self.ui.tabWidget.tabCloseRequested.connect(lambda index: self.ui.tabWidget.removeTab(index))
        

    # FUNCIONES DE MENU
    def mostrarPaginaInicio(self, cliked):
        if cliked:
            self.ui.stackedWidget.setCurrentIndex(0)
   
    def mostrarPaginaEncuesta(self, checked):
        if checked:
            self.ui.stackedWidget.setCurrentIndex(4)
            
    def mostrarPaginaBusqueda(self, checked):
        if checked:
            self.ui.stackedWidget.setCurrentIndex(1)
   
    def mostrarPaginaEstadisticas(self, checked):
        if checked:
            self.ui.stackedWidget.setCurrentIndex(3)

    def mostrarPaginaConfiguracion(self, checked):
        if checked:
            self.ui.stackedWidget.setCurrentIndex(2)
    
    def activarBot(self, cliked):
        if cliked:
            #send_email("Frank","fdiaz100604@gmail.com")
            print ('email')
        
    def mostrarPaginaEdicion(self, cliked):
        if cliked:
            self.ui.stackedWidget_2.setCurrentIndex(1)
            print("edit")
            self.ui.b_enviar_encuesta.setChecked(False)
      
    # FUNCIONES PARA AGREGAR TAB ESTADISTICAS      
    def nuevaEstadisticas(self,id):
        f_aux_stat = Estadisticas(id)
        f_aux_stat.listaGraficas()
        self.ui.tabWidget.addTab(f_aux_stat,'+')
        
        
    # FUNCIONES PARA AGREGAR PERFILES DE BUSQUEDAS
    def resultadoBusqueda(self):
        search=self.ui.lineEdit.text()
        
        for i in reversed(range(self.ui.scrollAreaContents.layout().count())):
            widget = self.ui.scrollAreaContents.layout().itemAt(i).widget()
            if widget:
                widget.deleteLater()
        
        self.busqueda=Busqueda(self,search)
        lista=self.busqueda.recuadro()
        for i in range (len(lista)):
            self.ui.scrollAreaContents.layout().insertWidget(0, lista[i])
        
class Estadisticas(QFrame):
    def __init__(self,idP):
        super(Estadisticas, self).__init__()
        self.ui = Ui_f_profe()
        self.ui.setupUi(self)
        self.id=idP
        self.informacion()
        # CONECCION DE LAS TAB EN AMBAS GRAFICAS
        self.ui.tab_graf_barra.currentChanged.connect(self.conectarGrafica)
        self.ui.tab_graf_linea.currentChanged.connect(self.conectarGrafica)
    
    # INICIALIZAION DE DATOS
    def informacion(self):
        datos=consultaId(self.id)
        self.ui.nombre_profe.setText(datos[0][1]+" - "+datos[0][3])
        self.ui.escuela_profe.setText(datos[0][2])
        # self.ui.perfil_profe.pixmap(img)
        self.ui.info_0.setText("Muy ineficiente: 1")
        self.ui.info_1.setText("Ineficiente: 2")
        self.ui.info_2.setText("Regular: 3")
        self.ui.info_3.setText("Eficiente: 4")
        self.ui.info_4.setText("Muy Eficiente: 5")
        
    # FUNCION DE CONEXION
    def conectarGrafica(self, indice):
        if self.sender() == self.ui.tab_graf_barra:
            self.ui.tab_graf_linea.setCurrentIndex(indice)
        elif self.sender() == self.ui.tab_graf_linea:
            self.ui.tab_graf_barra.setCurrentIndex(indice)
     
    def listaGraficas(self):
        cantM=tMaterias(self.id)
        self.tabGrafica(1,0)
        for i in range(len(cantM)):
            self.tabGrafica(0,cantM[i][0])
    
    def tabGrafica(self,graf,materia):
        tab_contein = GraphicTab(0,self.id,graf,materia)
        self.ui.tab_graf_barra.addTab(tab_contein, '+')

        tab_contein = GraphicTab(1,self.id,graf,materia)
        self.ui.tab_graf_linea.addTab(tab_contein, '+')
 
if __name__ == "__main__":
    app = QApplication([])
    window = App()
    window.show()
    app.exec()

# class User(QFrame):
#     def __init__(self):
#         super(User, self).__init__()
#         self.ui = Ui_Frame()
#         self.ui.setupUi(self)
#         self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        
#         centerPoint = QApplication.primaryScreen().availableGeometry().center()
#         frameGeometry = self.frameGeometry()
#         frameGeometry.moveCenter(centerPoint)
#         self.move(frameGeometry.topLeft())
      
#         self.show()