/********************************************************************************
** Form generated from reading UI file 'qt_formcMXJob.ui'
**
** Created by: Qt User Interface Compiler version 6.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef QT_FORMCMXJOB_H
#define QT_FORMCMXJOB_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *w_central;
    QVBoxLayout *verticalLayout;
    QFrame *f_cuerpo_up;
    QHBoxLayout *horizontalLayout;
    QFrame *f_logo;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *b_logo;
    QFrame *f_barra;
    QHBoxLayout *horizontalLayout_5;
    QSpacerItem *horizontalSpacer_5;
    QFrame *f_perfil;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *b_perfil;
    QFrame *f_cuerpo_dawn;
    QHBoxLayout *horizontalLayout_2;
    QFrame *f_m_icon;
    QVBoxLayout *verticalLayout_2;
    QPushButton *b_encuesta;
    QPushButton *b_shear;
    QPushButton *b_stats;
    QSpacerItem *verticalSpacer;
    QPushButton *b_config;
    QFrame *f_ventanas;
    QVBoxLayout *verticalLayout_4;
    QStackedWidget *stackedWidget;
    QWidget *pag_0;
    QHBoxLayout *horizontalLayout_10;
    QFrame *f_pag0_inicio;
    QVBoxLayout *verticalLayout_6;
    QLabel *label;
    QWidget *pag_1;
    QHBoxLayout *horizontalLayout_4;
    QFrame *f_pag4_shear;
    QVBoxLayout *verticalLayout_3;
    QFrame *f_shear_up;
    QHBoxLayout *horizontalLayout_11;
    QPushButton *b_shear_2;
    QLineEdit *lineEdit;
    QFrame *f_shear_dawn;
    QVBoxLayout *verticalLayout_5;
    QScrollArea *scrollArea;
    QWidget *scrollAreaContents;
    QVBoxLayout *verticalLayout_10;
    QSpacerItem *verticalSpacer_2;
    QWidget *pag_2;
    QHBoxLayout *horizontalLayout_16;
    QFrame *f_pag5_perfil;
    QHBoxLayout *horizontalLayout_17;
    QFrame *f_marco_perfil;
    QVBoxLayout *verticalLayout_15;
    QFrame *f_distribucuin_perfil;
    QGridLayout *gridLayout;
    QFrame *f_datos;
    QGridLayout *gridLayout_2;
    QLabel *label_escuela;
    QLabel *label_telefono;
    QLabel *label_correo;
    QLabel *label_direccion;
    QLabel *label_padsword;
    QLineEdit *lineedit_password;
    QLabel *label_img;
    QFrame *f_nick;
    QGridLayout *gridLayout_3;
    QLabel *label_nombre;
    QLabel *label_apellido;
    QLabel *label_nick;
    QFrame *frame;
    QHBoxLayout *horizontalLayout_24;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *b_ver_password;
    QPushButton *b_cambiar_pasworld;
    QSpacerItem *horizontalSpacer_3;
    QWidget *pag_3;
    QHBoxLayout *horizontalLayout_9;
    QFrame *f_pag3_config;
    QLabel *label_4;
    QWidget *pag_4;
    QHBoxLayout *horizontalLayout_7;
    QFrame *f_pag2_stats;
    QHBoxLayout *horizontalLayout_13;
    QTabWidget *tabWidget;
    QWidget *pag_5;
    QHBoxLayout *horizontalLayout_8;
    QFrame *f_pag1_encuesta;
    QHBoxLayout *horizontalLayout_12;
    QStackedWidget *stackedWidget_2;
    QWidget *e_pag_0;
    QVBoxLayout *verticalLayout_9;
    QFrame *f_epage0_dawn;
    QHBoxLayout *horizontalLayout_15;
    QPushButton *b_edit_encuesta;
    QFrame *line;
    QPushButton *b_enviar_encuesta;
    QWidget *e_pag_1;
    QVBoxLayout *verticalLayout_7;
    QFrame *f_edit_barr;
    QHBoxLayout *horizontalLayout_18;
    QSpacerItem *horizontalSpacer;
    QPushButton *b_atras_encuesta;
    QPushButton *b_cancelar_encuesta;
    QPushButton *b_guardar_encuesta;
    QFrame *f_edit_up;
    QHBoxLayout *horizontalLayout_19;
    QPushButton *b_categoria_1;
    QPushButton *b_categoria_2;
    QPushButton *b_categoria_3;
    QPushButton *b_categoria_4;
    QFrame *f_edit_dawn;
    QHBoxLayout *horizontalLayout_14;
    QStackedWidget *stackedWidget_3;
    QWidget *pregunta_pag1;
    QHBoxLayout *horizontalLayout_20;
    QFrame *f_cat1;
    QVBoxLayout *verticalLayout_8;
    QLabel *l_pregunta1_11;
    QLineEdit *lineedit_preg1_11;
    QLabel *l_pregunta2_11;
    QLineEdit *lineedit_preg2_11;
    QLabel *l_pregunta3_11;
    QLineEdit *lineedit_preg3_11;
    QLabel *l_pregunta4_11;
    QLineEdit *lineedit_preg4_11;
    QSpacerItem *verticalSpacer_3;
    QWidget *pregunta_pag2;
    QHBoxLayout *horizontalLayout_21;
    QFrame *f_cat2;
    QVBoxLayout *verticalLayout_12;
    QLabel *l_pregunta1_22;
    QLineEdit *lineedit_preg1_22;
    QLabel *l_pregunta2_22;
    QLineEdit *lineedit_preg2_22;
    QLabel *l_pregunta3_22;
    QLineEdit *lineedit_preg3_22;
    QLabel *l_pregunta4_22;
    QLineEdit *lineedit_preg4_22;
    QSpacerItem *verticalSpacer_5;
    QWidget *pregunta_pag4;
    QHBoxLayout *horizontalLayout_23;
    QFrame *f_cat4;
    QVBoxLayout *verticalLayout_14;
    QLabel *l_pregunta1_44;
    QLineEdit *lineedit_preg1_44;
    QLabel *l_pregunta2_44;
    QLineEdit *lineedit_preg2_44;
    QLabel *l_pregunta3_44;
    QLineEdit *lineedit_preg3_44;
    QLabel *l_pregunta4_44;
    QLineEdit *lineedit_preg4_44;
    QSpacerItem *verticalSpacer_7;
    QWidget *pregunta_pag3;
    QHBoxLayout *horizontalLayout_22;
    QFrame *f_cat3;
    QVBoxLayout *verticalLayout_13;
    QLabel *l_pregunta1_33;
    QLineEdit *lineedit_preg1_33;
    QLabel *l_pregunta2_33;
    QLineEdit *lineedit_preg2_33;
    QLabel *l_pregunta3_33;
    QLineEdit *lineedit_preg3_33;
    QLabel *l_pregunta4_33;
    QLineEdit *lineedit_preg4_33;
    QSpacerItem *verticalSpacer_6;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(820, 446);
        MainWindow->setMinimumSize(QSize(820, 420));
        MainWindow->setStyleSheet(QString::fromUtf8("QMainWindow { \n"
"	border: none;\n"
"}"));
        w_central = new QWidget(MainWindow);
        w_central->setObjectName("w_central");
        w_central->setStyleSheet(QString::fromUtf8("QWidget{\n"
"	background-color: rgb(25, 25, 25)\n"
"}"));
        verticalLayout = new QVBoxLayout(w_central);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        f_cuerpo_up = new QFrame(w_central);
        f_cuerpo_up->setObjectName("f_cuerpo_up");
        f_cuerpo_up->setMaximumSize(QSize(16777215, 40));
        f_cuerpo_up->setStyleSheet(QString::fromUtf8("QFrame {\n"
"    background: rgb(35, 35, 35);\n"
"    border-radius: 10px;\n"
"}\n"
""));
        f_cuerpo_up->setFrameShape(QFrame::Shape::NoFrame);
        f_cuerpo_up->setFrameShadow(QFrame::Shadow::Plain);
        horizontalLayout = new QHBoxLayout(f_cuerpo_up);
        horizontalLayout->setSpacing(0);
        horizontalLayout->setObjectName("horizontalLayout");
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        f_logo = new QFrame(f_cuerpo_up);
        f_logo->setObjectName("f_logo");
        f_logo->setMaximumSize(QSize(50, 40));
        f_logo->setFrameShape(QFrame::Shape::NoFrame);
        horizontalLayout_3 = new QHBoxLayout(f_logo);
        horizontalLayout_3->setSpacing(0);
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        b_logo = new QPushButton(f_logo);
        b_logo->setObjectName("b_logo");
        QSizePolicy sizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(b_logo->sizePolicy().hasHeightForWidth());
        b_logo->setSizePolicy(sizePolicy);
        b_logo->setAutoFillBackground(false);
        b_logo->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: rgba(40, 85, 165, 0.7);\n"
"	border-top-left-radius: 10px;\n"
"	border-top-right-radius: 10px;\n"
"	border: 0px solid;\n"
"    opacity: 0.5;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: rgba(55, 55, 145, 0.7);\n"
"}"));
        QIcon icon;
        icon.addFile(QString::fromUtf8("App_Icon/cropped-UGMA-LOGO-1-Photoroom (4).png"), QSize(), QIcon::Normal, QIcon::Off);
        b_logo->setIcon(icon);
        b_logo->setIconSize(QSize(70, 70));
        b_logo->setCheckable(false);

        horizontalLayout_3->addWidget(b_logo);


        horizontalLayout->addWidget(f_logo);

        f_barra = new QFrame(f_cuerpo_up);
        f_barra->setObjectName("f_barra");
        sizePolicy.setHeightForWidth(f_barra->sizePolicy().hasHeightForWidth());
        f_barra->setSizePolicy(sizePolicy);
        f_barra->setMaximumSize(QSize(4000, 40));
        f_barra->setFrameShape(QFrame::Shape::NoFrame);
        horizontalLayout_5 = new QHBoxLayout(f_barra);
        horizontalLayout_5->setSpacing(0);
        horizontalLayout_5->setObjectName("horizontalLayout_5");
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_5);

        f_perfil = new QFrame(f_barra);
        f_perfil->setObjectName("f_perfil");
        f_perfil->setMaximumSize(QSize(60, 40));
        f_perfil->setFrameShape(QFrame::Shape::NoFrame);
        horizontalLayout_6 = new QHBoxLayout(f_perfil);
        horizontalLayout_6->setSpacing(0);
        horizontalLayout_6->setObjectName("horizontalLayout_6");
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        b_perfil = new QPushButton(f_perfil);
        b_perfil->setObjectName("b_perfil");
        b_perfil->setMinimumSize(QSize(40, 40));
        b_perfil->setMaximumSize(QSize(40, 40));
        b_perfil->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	background: rgb(55, 55, 55);\n"
"	color: rgb(255, 255, 255);\n"
"	border: 0px soild;\n"
"	border-radius: 10px;\n"
"}\n"
"QPushButton:hover{\n"
"	background-color: rgba(40, 85, 165, 0.4);\n"
"	border-radius: 10px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: rgba(55, 55, 145, 0.7);\n"
"}"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("App_Icon/person_40dp_FILL0_wght400_GRAD0_opsz40 (1).png"), QSize(), QIcon::Normal, QIcon::Off);
        b_perfil->setIcon(icon1);
        b_perfil->setIconSize(QSize(24, 24));
        b_perfil->setCheckable(false);

        horizontalLayout_6->addWidget(b_perfil);


        horizontalLayout_5->addWidget(f_perfil, 0, Qt::AlignmentFlag::AlignRight);


        horizontalLayout->addWidget(f_barra);


        verticalLayout->addWidget(f_cuerpo_up);

        f_cuerpo_dawn = new QFrame(w_central);
        f_cuerpo_dawn->setObjectName("f_cuerpo_dawn");
        f_cuerpo_dawn->setFrameShape(QFrame::Shape::NoFrame);
        horizontalLayout_2 = new QHBoxLayout(f_cuerpo_dawn);
        horizontalLayout_2->setSpacing(0);
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        f_m_icon = new QFrame(f_cuerpo_dawn);
        f_m_icon->setObjectName("f_m_icon");
        f_m_icon->setMinimumSize(QSize(50, 0));
        f_m_icon->setMaximumSize(QSize(50, 4000));
        f_m_icon->setLayoutDirection(Qt::LayoutDirection::LeftToRight);
        f_m_icon->setStyleSheet(QString::fromUtf8("QFrame {\n"
"    background: rgb(35, 35, 35);\n"
"    border-radius: 10px;\n"
"}\n"
""));
        f_m_icon->setFrameShape(QFrame::Shape::NoFrame);
        verticalLayout_2 = new QVBoxLayout(f_m_icon);
        verticalLayout_2->setSpacing(0);
        verticalLayout_2->setObjectName("verticalLayout_2");
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        b_encuesta = new QPushButton(f_m_icon);
        b_encuesta->setObjectName("b_encuesta");
        b_encuesta->setMinimumSize(QSize(50, 40));
        b_encuesta->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	background: rgb(35, 35, 35);\n"
"	color: rgb(255, 255, 255);\n"
"	border: 0px soild\n"
"}\n"
"QPushButton:hover{\n"
"	background-color: rgba(40, 85, 165, 0.4);\n"
"	border-radius: 10px;\n"
"}\n"
"QPushButton:checked {\n"
"    background-color: rgba(40, 85, 165, 0.7);\n"
"	border-bottom-left-radius: 10px;\n"
" 	/*border-top-left-radius: 10px;*/\n"
"}\n"
""));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8("App_Icon/wysiwyg_40dp_FILL0_wght400_GRAD0_opsz40 (1).png"), QSize(), QIcon::Normal, QIcon::Off);
        b_encuesta->setIcon(icon2);
        b_encuesta->setIconSize(QSize(24, 24));
        b_encuesta->setCheckable(true);
        b_encuesta->setAutoExclusive(true);
        b_encuesta->setAutoDefault(false);

        verticalLayout_2->addWidget(b_encuesta);

        b_shear = new QPushButton(f_m_icon);
        b_shear->setObjectName("b_shear");
        b_shear->setMinimumSize(QSize(50, 40));
        b_shear->setMouseTracking(true);
        b_shear->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	background: rgb(35, 35, 35);\n"
"	color: rgb(255, 255, 255);\n"
"	border: 0px soild\n"
"}\n"
"QPushButton:hover{\n"
"	background-color: rgba(40, 85, 165, 0.4);\n"
"	border-radius: 10px;\n"
"}\n"
"QPushButton:checked {\n"
"    background-color: rgba(40, 85, 165, 0.7);\n"
"	border-bottom-left-radius: 10px;\n"
" 	border-top-left-radius: 10px;\n"
"}\n"
""));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8("App_Icon/person_search_40dp_FILL0_wght400_GRAD0_opsz40 (1).png"), QSize(), QIcon::Normal, QIcon::Off);
        b_shear->setIcon(icon3);
        b_shear->setIconSize(QSize(24, 24));
        b_shear->setCheckable(true);
        b_shear->setAutoExclusive(true);

        verticalLayout_2->addWidget(b_shear);

        b_stats = new QPushButton(f_m_icon);
        b_stats->setObjectName("b_stats");
        b_stats->setMinimumSize(QSize(50, 40));
        b_stats->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	background: rgb(35, 35, 35);\n"
"	color: rgb(255, 255, 255);\n"
"	border: 0px soild\n"
"}\n"
"QPushButton:hover{\n"
"	background-color: rgba(40, 85, 165, 0.4);\n"
"	border-radius: 10px;\n"
"}\n"
"QPushButton:checked {\n"
"    background-color: rgba(40, 85, 165, 0.7);\n"
"	border-bottom-left-radius: 10px;\n"
" 	border-top-left-radius: 10px;\n"
"}"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8("App_Icon/stacked_bar_chart_40dp_FILL0_wght400_GRAD0_opsz40.png"), QSize(), QIcon::Normal, QIcon::Off);
        b_stats->setIcon(icon4);
        b_stats->setIconSize(QSize(24, 24));
        b_stats->setCheckable(true);
        b_stats->setAutoExclusive(true);

        verticalLayout_2->addWidget(b_stats);

        verticalSpacer = new QSpacerItem(20, 257, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);

        b_config = new QPushButton(f_m_icon);
        b_config->setObjectName("b_config");
        b_config->setMinimumSize(QSize(50, 40));
        b_config->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	background: rgb(35, 35, 35);\n"
"	color: rgb(255, 255, 255);\n"
"	border: 0px soild\n"
"}\n"
"QPushButton:hover{\n"
"	background-color: rgba(40, 85, 165, 0.4);\n"
"	border-radius: 10px;\n"
"}\n"
"QPushButton:checked {\n"
"    background-color: rgba(40, 85, 165, 0.7);\n"
"	border-bottom-left-radius: 10px;\n"
"	border-radius: 10px;\n"
"}"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8("App_Icon/toggle_off_40dp_FILL0_wght400_GRAD0_opsz40 (1).png"), QSize(), QIcon::Normal, QIcon::Off);
        icon5.addFile(QString::fromUtf8("App_Icon/toggle_on_40dp_FILL0_wght400_GRAD0_opsz40.png"), QSize(), QIcon::Normal, QIcon::On);
        b_config->setIcon(icon5);
        b_config->setIconSize(QSize(24, 24));
        b_config->setCheckable(true);
        b_config->setAutoExclusive(true);

        verticalLayout_2->addWidget(b_config);


        horizontalLayout_2->addWidget(f_m_icon);

        f_ventanas = new QFrame(f_cuerpo_dawn);
        f_ventanas->setObjectName("f_ventanas");
        sizePolicy.setHeightForWidth(f_ventanas->sizePolicy().hasHeightForWidth());
        f_ventanas->setSizePolicy(sizePolicy);
        f_ventanas->setFrameShape(QFrame::Shape::NoFrame);
        verticalLayout_4 = new QVBoxLayout(f_ventanas);
        verticalLayout_4->setSpacing(0);
        verticalLayout_4->setObjectName("verticalLayout_4");
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        stackedWidget = new QStackedWidget(f_ventanas);
        stackedWidget->setObjectName("stackedWidget");
        stackedWidget->setLayoutDirection(Qt::LayoutDirection::LeftToRight);
        pag_0 = new QWidget();
        pag_0->setObjectName("pag_0");
        horizontalLayout_10 = new QHBoxLayout(pag_0);
        horizontalLayout_10->setSpacing(0);
        horizontalLayout_10->setObjectName("horizontalLayout_10");
        horizontalLayout_10->setContentsMargins(0, 0, 0, 0);
        f_pag0_inicio = new QFrame(pag_0);
        f_pag0_inicio->setObjectName("f_pag0_inicio");
        f_pag0_inicio->setFrameShape(QFrame::Shape::NoFrame);
        verticalLayout_6 = new QVBoxLayout(f_pag0_inicio);
        verticalLayout_6->setSpacing(0);
        verticalLayout_6->setObjectName("verticalLayout_6");
        verticalLayout_6->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(f_pag0_inicio);
        label->setObjectName("label");
        QSizePolicy sizePolicy1(QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Minimum);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy1);
        label->setMinimumSize(QSize(64, 64));
        label->setMaximumSize(QSize(430, 325));
        label->setPixmap(QPixmap(QString::fromUtf8("App_Icon/cropped-UGMA-LOGO-1-Photoroom (6).png")));
        label->setScaledContents(true);
        label->setAlignment(Qt::AlignmentFlag::AlignCenter);

        verticalLayout_6->addWidget(label, 0, Qt::AlignmentFlag::AlignHCenter|Qt::AlignmentFlag::AlignVCenter);


        horizontalLayout_10->addWidget(f_pag0_inicio);

        stackedWidget->addWidget(pag_0);
        pag_1 = new QWidget();
        pag_1->setObjectName("pag_1");
        horizontalLayout_4 = new QHBoxLayout(pag_1);
        horizontalLayout_4->setSpacing(0);
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        f_pag4_shear = new QFrame(pag_1);
        f_pag4_shear->setObjectName("f_pag4_shear");
        f_pag4_shear->setFrameShape(QFrame::Shape::NoFrame);
        f_pag4_shear->setFrameShadow(QFrame::Shadow::Raised);
        verticalLayout_3 = new QVBoxLayout(f_pag4_shear);
        verticalLayout_3->setSpacing(10);
        verticalLayout_3->setObjectName("verticalLayout_3");
        verticalLayout_3->setContentsMargins(10, 10, 10, 10);
        f_shear_up = new QFrame(f_pag4_shear);
        f_shear_up->setObjectName("f_shear_up");
        f_shear_up->setMaximumSize(QSize(16777215, 40));
        f_shear_up->setLayoutDirection(Qt::LayoutDirection::RightToLeft);
        f_shear_up->setStyleSheet(QString::fromUtf8("QFrame {\n"
"    background: rgba(60, 60, 60, 0.7);\n"
"    border-radius: 10px;\n"
"}\n"
""));
        f_shear_up->setFrameShape(QFrame::Shape::StyledPanel);
        f_shear_up->setFrameShadow(QFrame::Shadow::Raised);
        horizontalLayout_11 = new QHBoxLayout(f_shear_up);
        horizontalLayout_11->setSpacing(0);
        horizontalLayout_11->setObjectName("horizontalLayout_11");
        horizontalLayout_11->setContentsMargins(0, 0, 0, 0);
        b_shear_2 = new QPushButton(f_shear_up);
        b_shear_2->setObjectName("b_shear_2");
        b_shear_2->setMinimumSize(QSize(50, 35));
        b_shear_2->setMaximumSize(QSize(50, 35));
        b_shear_2->setMouseTracking(true);
        b_shear_2->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	background: rgb(55, 55, 55);\n"
"	color: rgb(255, 255, 255);\n"
"	border: 0px soild;\n"
"	border-bottom-right-radius: 10px;\n"
"}\n"
"QPushButton:hover{\n"
"	background-color: rgba(40, 85, 165, 0.4);\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: rgba(55, 55, 145, 0.7);\n"
"}"));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8("App_Icon/search_40dp_FILL0_wght400_GRAD0_opsz40 (1).png"), QSize(), QIcon::Normal, QIcon::Off);
        b_shear_2->setIcon(icon6);
        b_shear_2->setIconSize(QSize(24, 24));
        b_shear_2->setCheckable(false);
        b_shear_2->setAutoExclusive(false);

        horizontalLayout_11->addWidget(b_shear_2);

        lineEdit = new QLineEdit(f_shear_up);
        lineEdit->setObjectName("lineEdit");
        lineEdit->setMinimumSize(QSize(300, 35));
        lineEdit->setMaximumSize(QSize(400, 35));
        QFont font;
        font.setFamilies({QString::fromUtf8("Arial")});
        font.setPointSize(12);
        lineEdit->setFont(font);
        lineEdit->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:1, y2:0,\n"
"	stop:0 rgb(105, 105, 105),\n"
"	stop:1 rgb(55, 55, 55));\n"
"    border-bottom-left-radius: 10px;\n"
"}"));
        lineEdit->setEchoMode(QLineEdit::EchoMode::Normal);
        lineEdit->setAlignment(Qt::AlignmentFlag::AlignCenter);
        lineEdit->setDragEnabled(true);
        lineEdit->setCursorMoveStyle(Qt::CursorMoveStyle::LogicalMoveStyle);
        lineEdit->setClearButtonEnabled(false);

        horizontalLayout_11->addWidget(lineEdit);


        verticalLayout_3->addWidget(f_shear_up, 0, Qt::AlignmentFlag::AlignHCenter);

        f_shear_dawn = new QFrame(f_pag4_shear);
        f_shear_dawn->setObjectName("f_shear_dawn");
        f_shear_dawn->setStyleSheet(QString::fromUtf8("background: rgba(35, 35, 35,1);\n"
"border-radius: 10px;"));
        f_shear_dawn->setFrameShape(QFrame::Shape::NoFrame);
        f_shear_dawn->setFrameShadow(QFrame::Shadow::Raised);
        verticalLayout_5 = new QVBoxLayout(f_shear_dawn);
        verticalLayout_5->setSpacing(5);
        verticalLayout_5->setObjectName("verticalLayout_5");
        verticalLayout_5->setContentsMargins(10, 10, 10, 10);
        scrollArea = new QScrollArea(f_shear_dawn);
        scrollArea->setObjectName("scrollArea");
        scrollArea->setStyleSheet(QString::fromUtf8("/*QScrollBar:vertical {\n"
"	background: qlineargradient(spread:pad, x1:0, y1:1, x2:1, y2:0,\n"
"	stop:0 rgb(105, 105, 105),\n"
"	stop:1rgb(130, 130, 130));\n"
"	border-radius: 15px; \n"
"	width: 10px; \n"
"}\n"
"QScrollBar::handle:vertical {\n"
"	background: rgb(55, 55, 55);\n"
"	border-radius: 15px; \n"
"}\n"
"\n"
"QScrollBar::handle:hover{\n"
"	background: rgb(55, 55, 145);\n"
"}*/\n"
"QScrollBar:vertical {\n"
"	background: rgb(105, 105, 105);\n"
"	border-radius: 15px; \n"
"	width: 10px; \n"
"}\n"
"QScrollBar::handle:vertical {\n"
"	background: rgb(55, 55, 55);\n"
"	border-radius: 15px; \n"
"}"));
        scrollArea->setWidgetResizable(true);
        scrollAreaContents = new QWidget();
        scrollAreaContents->setObjectName("scrollAreaContents");
        scrollAreaContents->setGeometry(QRect(0, 0, 730, 321));
        verticalLayout_10 = new QVBoxLayout(scrollAreaContents);
        verticalLayout_10->setSpacing(0);
        verticalLayout_10->setObjectName("verticalLayout_10");
        verticalLayout_10->setContentsMargins(0, -1, 0, -1);
        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        verticalLayout_10->addItem(verticalSpacer_2);

        scrollArea->setWidget(scrollAreaContents);

        verticalLayout_5->addWidget(scrollArea);


        verticalLayout_3->addWidget(f_shear_dawn);


        horizontalLayout_4->addWidget(f_pag4_shear);

        stackedWidget->addWidget(pag_1);
        pag_2 = new QWidget();
        pag_2->setObjectName("pag_2");
        horizontalLayout_16 = new QHBoxLayout(pag_2);
        horizontalLayout_16->setSpacing(0);
        horizontalLayout_16->setObjectName("horizontalLayout_16");
        horizontalLayout_16->setContentsMargins(0, 0, 0, 0);
        f_pag5_perfil = new QFrame(pag_2);
        f_pag5_perfil->setObjectName("f_pag5_perfil");
        f_pag5_perfil->setFrameShape(QFrame::Shape::NoFrame);
        f_pag5_perfil->setFrameShadow(QFrame::Shadow::Raised);
        horizontalLayout_17 = new QHBoxLayout(f_pag5_perfil);
        horizontalLayout_17->setSpacing(10);
        horizontalLayout_17->setObjectName("horizontalLayout_17");
        horizontalLayout_17->setContentsMargins(10, 10, 10, 10);
        f_marco_perfil = new QFrame(f_pag5_perfil);
        f_marco_perfil->setObjectName("f_marco_perfil");
        QSizePolicy sizePolicy2(QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Ignored);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(f_marco_perfil->sizePolicy().hasHeightForWidth());
        f_marco_perfil->setSizePolicy(sizePolicy2);
        f_marco_perfil->setMinimumSize(QSize(500, 300));
        f_marco_perfil->setMaximumSize(QSize(1000, 500));
        f_marco_perfil->setStyleSheet(QString::fromUtf8(""));
        f_marco_perfil->setFrameShape(QFrame::Shape::NoFrame);
        f_marco_perfil->setFrameShadow(QFrame::Shadow::Plain);
        verticalLayout_15 = new QVBoxLayout(f_marco_perfil);
        verticalLayout_15->setSpacing(5);
        verticalLayout_15->setObjectName("verticalLayout_15");
        verticalLayout_15->setContentsMargins(10, 10, 10, 10);
        f_distribucuin_perfil = new QFrame(f_marco_perfil);
        f_distribucuin_perfil->setObjectName("f_distribucuin_perfil");
        f_distribucuin_perfil->setStyleSheet(QString::fromUtf8("/*background: rgba(105, 105, 105, 0.4);\n"
"border-radius: 10px; */\n"
"background: rgba(70, 70, 70, 0.4);\n"
"border-radius: 10px;"));
        f_distribucuin_perfil->setFrameShape(QFrame::Shape::StyledPanel);
        f_distribucuin_perfil->setFrameShadow(QFrame::Shadow::Raised);
        gridLayout = new QGridLayout(f_distribucuin_perfil);
        gridLayout->setObjectName("gridLayout");
        f_datos = new QFrame(f_distribucuin_perfil);
        f_datos->setObjectName("f_datos");
        sizePolicy.setHeightForWidth(f_datos->sizePolicy().hasHeightForWidth());
        f_datos->setSizePolicy(sizePolicy);
        f_datos->setFrameShape(QFrame::Shape::StyledPanel);
        f_datos->setFrameShadow(QFrame::Shadow::Raised);
        gridLayout_2 = new QGridLayout(f_datos);
        gridLayout_2->setObjectName("gridLayout_2");
        label_escuela = new QLabel(f_datos);
        label_escuela->setObjectName("label_escuela");
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Tw Cen MT Condensed")});
        font1.setPointSize(14);
        label_escuela->setFont(font1);
        label_escuela->setMargin(5);
        label_escuela->setIndent(5);

        gridLayout_2->addWidget(label_escuela, 0, 0, 1, 1);

        label_telefono = new QLabel(f_datos);
        label_telefono->setObjectName("label_telefono");
        label_telefono->setFont(font1);
        label_telefono->setMargin(5);
        label_telefono->setIndent(5);

        gridLayout_2->addWidget(label_telefono, 0, 1, 1, 1);

        label_correo = new QLabel(f_datos);
        label_correo->setObjectName("label_correo");
        label_correo->setFont(font1);
        label_correo->setMargin(5);
        label_correo->setIndent(5);

        gridLayout_2->addWidget(label_correo, 1, 0, 1, 1);

        label_direccion = new QLabel(f_datos);
        label_direccion->setObjectName("label_direccion");
        label_direccion->setFont(font1);
        label_direccion->setMargin(5);
        label_direccion->setIndent(5);

        gridLayout_2->addWidget(label_direccion, 1, 1, 1, 1);

        label_padsword = new QLabel(f_datos);
        label_padsword->setObjectName("label_padsword");
        label_padsword->setMinimumSize(QSize(200, 0));
        label_padsword->setFont(font1);
        label_padsword->setStyleSheet(QString::fromUtf8("background: rgba(105, 105, 105, 0);"));
        label_padsword->setAlignment(Qt::AlignmentFlag::AlignRight|Qt::AlignmentFlag::AlignTrailing|Qt::AlignmentFlag::AlignVCenter);
        label_padsword->setMargin(5);
        label_padsword->setIndent(5);

        gridLayout_2->addWidget(label_padsword, 2, 0, 1, 1, Qt::AlignmentFlag::AlignRight);

        lineedit_password = new QLineEdit(f_datos);
        lineedit_password->setObjectName("lineedit_password");
        sizePolicy.setHeightForWidth(lineedit_password->sizePolicy().hasHeightForWidth());
        lineedit_password->setSizePolicy(sizePolicy);
        lineedit_password->setMinimumSize(QSize(200, 0));
        lineedit_password->setFont(font1);
        lineedit_password->setStyleSheet(QString::fromUtf8("QLineEdit { \n"
"	padding-left: 5px; \n"
"}"));
        lineedit_password->setInputMask(QString::fromUtf8(""));
        lineedit_password->setEchoMode(QLineEdit::EchoMode::Password);
        lineedit_password->setCursorPosition(4);
        lineedit_password->setAlignment(Qt::AlignmentFlag::AlignLeading|Qt::AlignmentFlag::AlignLeft|Qt::AlignmentFlag::AlignVCenter);
        lineedit_password->setDragEnabled(false);
        lineedit_password->setReadOnly(true);
        lineedit_password->setPlaceholderText(QString::fromUtf8(""));
        lineedit_password->setClearButtonEnabled(false);

        gridLayout_2->addWidget(lineedit_password, 2, 1, 1, 1, Qt::AlignmentFlag::AlignLeft);


        gridLayout->addWidget(f_datos, 1, 0, 1, 2);

        label_img = new QLabel(f_distribucuin_perfil);
        label_img->setObjectName("label_img");
        sizePolicy.setHeightForWidth(label_img->sizePolicy().hasHeightForWidth());
        label_img->setSizePolicy(sizePolicy);
        label_img->setMinimumSize(QSize(130, 130));
        label_img->setPixmap(QPixmap(QString::fromUtf8("App_Icon/account_circle_40dp_FILL0_wght400_GRAD0_opsz40 (1).png")));

        gridLayout->addWidget(label_img, 0, 0, 1, 1);

        f_nick = new QFrame(f_distribucuin_perfil);
        f_nick->setObjectName("f_nick");
        QSizePolicy sizePolicy3(QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(f_nick->sizePolicy().hasHeightForWidth());
        f_nick->setSizePolicy(sizePolicy3);
        f_nick->setMinimumSize(QSize(130, 130));
        f_nick->setFrameShape(QFrame::Shape::StyledPanel);
        f_nick->setFrameShadow(QFrame::Shadow::Raised);
        gridLayout_3 = new QGridLayout(f_nick);
        gridLayout_3->setObjectName("gridLayout_3");
        label_nombre = new QLabel(f_nick);
        label_nombre->setObjectName("label_nombre");
        sizePolicy3.setHeightForWidth(label_nombre->sizePolicy().hasHeightForWidth());
        label_nombre->setSizePolicy(sizePolicy3);
        label_nombre->setMinimumSize(QSize(200, 0));
        QFont font2;
        font2.setFamilies({QString::fromUtf8("Bahnschrift SemiLight Condensed")});
        font2.setPointSize(12);
        label_nombre->setFont(font2);
        label_nombre->setStyleSheet(QString::fromUtf8("background: rgba(105, 105, 105,0);"));
        label_nombre->setMargin(5);
        label_nombre->setIndent(5);

        gridLayout_3->addWidget(label_nombre, 1, 1, 1, 1);

        label_apellido = new QLabel(f_nick);
        label_apellido->setObjectName("label_apellido");
        sizePolicy3.setHeightForWidth(label_apellido->sizePolicy().hasHeightForWidth());
        label_apellido->setSizePolicy(sizePolicy3);
        label_apellido->setMinimumSize(QSize(200, 0));
        QFont font3;
        font3.setFamilies({QString::fromUtf8("Bahnschrift SemiLight Condensed")});
        font3.setPointSize(12);
        font3.setBold(false);
        label_apellido->setFont(font3);
        label_apellido->setStyleSheet(QString::fromUtf8("background: rgba(105, 105, 105, 0);"));
        label_apellido->setMargin(5);
        label_apellido->setIndent(5);

        gridLayout_3->addWidget(label_apellido, 1, 0, 1, 1);

        label_nick = new QLabel(f_nick);
        label_nick->setObjectName("label_nick");
        sizePolicy.setHeightForWidth(label_nick->sizePolicy().hasHeightForWidth());
        label_nick->setSizePolicy(sizePolicy);
        label_nick->setMinimumSize(QSize(200, 0));
        QFont font4;
        font4.setFamilies({QString::fromUtf8("Bahnschrift SemiBold Condensed")});
        font4.setPointSize(14);
        font4.setBold(true);
        label_nick->setFont(font4);
        label_nick->setMargin(5);
        label_nick->setIndent(5);

        gridLayout_3->addWidget(label_nick, 0, 0, 1, 1);


        gridLayout->addWidget(f_nick, 0, 1, 1, 1);


        verticalLayout_15->addWidget(f_distribucuin_perfil);

        frame = new QFrame(f_marco_perfil);
        frame->setObjectName("frame");
        sizePolicy.setHeightForWidth(frame->sizePolicy().hasHeightForWidth());
        frame->setSizePolicy(sizePolicy);
        frame->setMinimumSize(QSize(0, 30));
        frame->setMaximumSize(QSize(16777215, 50));
        frame->setStyleSheet(QString::fromUtf8("background: rgba(70, 70, 70, 0.4);\n"
"border-radius: 10px;"));
        frame->setFrameShape(QFrame::Shape::StyledPanel);
        frame->setFrameShadow(QFrame::Shadow::Raised);
        horizontalLayout_24 = new QHBoxLayout(frame);
        horizontalLayout_24->setSpacing(5);
        horizontalLayout_24->setObjectName("horizontalLayout_24");
        horizontalLayout_24->setContentsMargins(10, 10, 10, 10);
        horizontalSpacer_2 = new QSpacerItem(200, 20, QSizePolicy::Policy::Maximum, QSizePolicy::Policy::Minimum);

        horizontalLayout_24->addItem(horizontalSpacer_2);

        b_ver_password = new QPushButton(frame);
        b_ver_password->setObjectName("b_ver_password");
        QSizePolicy sizePolicy4(QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Preferred);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(b_ver_password->sizePolicy().hasHeightForWidth());
        b_ver_password->setSizePolicy(sizePolicy4);
        b_ver_password->setMinimumSize(QSize(100, 30));
        b_ver_password->setMaximumSize(QSize(200, 50));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8("App_Icon/visibility_off_40dp_FILL0_wght400_GRAD0_opsz40.png"), QSize(), QIcon::Normal, QIcon::Off);
        icon7.addFile(QString::fromUtf8("App_Icon/visibility_40dp_FILL0_wght400_GRAD0_opsz40 (1).png"), QSize(), QIcon::Normal, QIcon::On);
        b_ver_password->setIcon(icon7);
        b_ver_password->setCheckable(true);
        b_ver_password->setChecked(false);
        b_ver_password->setAutoRepeat(false);

        horizontalLayout_24->addWidget(b_ver_password);

        b_cambiar_pasworld = new QPushButton(frame);
        b_cambiar_pasworld->setObjectName("b_cambiar_pasworld");
        sizePolicy4.setHeightForWidth(b_cambiar_pasworld->sizePolicy().hasHeightForWidth());
        b_cambiar_pasworld->setSizePolicy(sizePolicy4);
        b_cambiar_pasworld->setMinimumSize(QSize(100, 30));
        b_cambiar_pasworld->setMaximumSize(QSize(200, 50));
        QIcon icon8;
        icon8.addFile(QString::fromUtf8("App_Icon/app_registration_40dp_FILL0_wght400_GRAD0_opsz40 (1).png"), QSize(), QIcon::Normal, QIcon::Off);
        b_cambiar_pasworld->setIcon(icon8);

        horizontalLayout_24->addWidget(b_cambiar_pasworld);

        horizontalSpacer_3 = new QSpacerItem(200, 20, QSizePolicy::Policy::Maximum, QSizePolicy::Policy::Minimum);

        horizontalLayout_24->addItem(horizontalSpacer_3);


        verticalLayout_15->addWidget(frame);


        horizontalLayout_17->addWidget(f_marco_perfil);


        horizontalLayout_16->addWidget(f_pag5_perfil);

        stackedWidget->addWidget(pag_2);
        pag_3 = new QWidget();
        pag_3->setObjectName("pag_3");
        horizontalLayout_9 = new QHBoxLayout(pag_3);
        horizontalLayout_9->setSpacing(0);
        horizontalLayout_9->setObjectName("horizontalLayout_9");
        horizontalLayout_9->setContentsMargins(0, 0, 0, 0);
        f_pag3_config = new QFrame(pag_3);
        f_pag3_config->setObjectName("f_pag3_config");
        f_pag3_config->setFrameShape(QFrame::Shape::NoFrame);
        f_pag3_config->setFrameShadow(QFrame::Shadow::Raised);
        label_4 = new QLabel(f_pag3_config);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(40, 210, 691, 361));
        label_4->setMinimumSize(QSize(32, 32));
        label_4->setPixmap(QPixmap(QString::fromUtf8("../../.designer/VS Code/PROYECTO QT PY/APP/images/images/ugma.png")));

        horizontalLayout_9->addWidget(f_pag3_config);

        stackedWidget->addWidget(pag_3);
        pag_4 = new QWidget();
        pag_4->setObjectName("pag_4");
        QSizePolicy sizePolicy5(QSizePolicy::Policy::Maximum, QSizePolicy::Policy::Maximum);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(pag_4->sizePolicy().hasHeightForWidth());
        pag_4->setSizePolicy(sizePolicy5);
        horizontalLayout_7 = new QHBoxLayout(pag_4);
        horizontalLayout_7->setSpacing(0);
        horizontalLayout_7->setObjectName("horizontalLayout_7");
        horizontalLayout_7->setContentsMargins(0, 0, 0, 0);
        f_pag2_stats = new QFrame(pag_4);
        f_pag2_stats->setObjectName("f_pag2_stats");
        f_pag2_stats->setFrameShape(QFrame::Shape::NoFrame);
        f_pag2_stats->setFrameShadow(QFrame::Shadow::Raised);
        horizontalLayout_13 = new QHBoxLayout(f_pag2_stats);
        horizontalLayout_13->setObjectName("horizontalLayout_13");
        tabWidget = new QTabWidget(f_pag2_stats);
        tabWidget->setObjectName("tabWidget");
        tabWidget->setTabsClosable(true);

        horizontalLayout_13->addWidget(tabWidget);


        horizontalLayout_7->addWidget(f_pag2_stats);

        stackedWidget->addWidget(pag_4);
        pag_5 = new QWidget();
        pag_5->setObjectName("pag_5");
        horizontalLayout_8 = new QHBoxLayout(pag_5);
        horizontalLayout_8->setSpacing(0);
        horizontalLayout_8->setObjectName("horizontalLayout_8");
        horizontalLayout_8->setContentsMargins(0, 0, 0, 0);
        f_pag1_encuesta = new QFrame(pag_5);
        f_pag1_encuesta->setObjectName("f_pag1_encuesta");
        f_pag1_encuesta->setFrameShape(QFrame::Shape::NoFrame);
        f_pag1_encuesta->setFrameShadow(QFrame::Shadow::Raised);
        horizontalLayout_12 = new QHBoxLayout(f_pag1_encuesta);
        horizontalLayout_12->setSpacing(10);
        horizontalLayout_12->setObjectName("horizontalLayout_12");
        horizontalLayout_12->setContentsMargins(10, 10, 10, 10);
        stackedWidget_2 = new QStackedWidget(f_pag1_encuesta);
        stackedWidget_2->setObjectName("stackedWidget_2");
        e_pag_0 = new QWidget();
        e_pag_0->setObjectName("e_pag_0");
        verticalLayout_9 = new QVBoxLayout(e_pag_0);
        verticalLayout_9->setSpacing(0);
        verticalLayout_9->setObjectName("verticalLayout_9");
        verticalLayout_9->setContentsMargins(0, 0, 0, 0);
        f_epage0_dawn = new QFrame(e_pag_0);
        f_epage0_dawn->setObjectName("f_epage0_dawn");
        f_epage0_dawn->setStyleSheet(QString::fromUtf8("background: rgba(70, 70, 70, 0.4);\n"
"border-radius: 10px;"));
        f_epage0_dawn->setFrameShape(QFrame::Shape::NoFrame);
        f_epage0_dawn->setFrameShadow(QFrame::Shadow::Raised);
        horizontalLayout_15 = new QHBoxLayout(f_epage0_dawn);
        horizontalLayout_15->setSpacing(5);
        horizontalLayout_15->setObjectName("horizontalLayout_15");
        horizontalLayout_15->setContentsMargins(10, 10, 10, 10);
        b_edit_encuesta = new QPushButton(f_epage0_dawn);
        b_edit_encuesta->setObjectName("b_edit_encuesta");
        QSizePolicy sizePolicy6(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Expanding);
        sizePolicy6.setHorizontalStretch(0);
        sizePolicy6.setVerticalStretch(0);
        sizePolicy6.setHeightForWidth(b_edit_encuesta->sizePolicy().hasHeightForWidth());
        b_edit_encuesta->setSizePolicy(sizePolicy6);
        QFont font5;
        font5.setFamilies({QString::fromUtf8("Tw Cen MT Condensed")});
        font5.setPointSize(26);
        font5.setHintingPreference(QFont::PreferDefaultHinting);
        b_edit_encuesta->setFont(font5);
        b_edit_encuesta->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	color: rgb(255, 255, 255);\n"
"	border: 0px soild;\n"
"	border-radius: 10px;\n"
"}\n"
"QPushButton:hover{\n"
"	background-color: rgba(40, 85, 165, 0.4);\n"
"	border-radius: 10px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: rgba(55, 55, 145, 0.7);\n"
"}"));
        QIcon icon9;
        icon9.addFile(QString::fromUtf8("App_Icon/edit_document_40dp_FILL0_wght400_GRAD0_opsz40.png"), QSize(), QIcon::Normal, QIcon::Off);
        b_edit_encuesta->setIcon(icon9);
        b_edit_encuesta->setIconSize(QSize(90, 90));
        b_edit_encuesta->setCheckable(false);

        horizontalLayout_15->addWidget(b_edit_encuesta);

        line = new QFrame(f_epage0_dawn);
        line->setObjectName("line");
        line->setStyleSheet(QString::fromUtf8("background: rgb(60, 60, 60);\n"
"border-radius: 10px; "));
        line->setFrameShape(QFrame::Shape::VLine);
        line->setFrameShadow(QFrame::Shadow::Sunken);

        horizontalLayout_15->addWidget(line);

        b_enviar_encuesta = new QPushButton(f_epage0_dawn);
        b_enviar_encuesta->setObjectName("b_enviar_encuesta");
        sizePolicy6.setHeightForWidth(b_enviar_encuesta->sizePolicy().hasHeightForWidth());
        b_enviar_encuesta->setSizePolicy(sizePolicy6);
        QFont font6;
        font6.setFamilies({QString::fromUtf8("Tw Cen MT Condensed")});
        font6.setPointSize(26);
        font6.setBold(false);
        b_enviar_encuesta->setFont(font6);
        b_enviar_encuesta->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	color: rgb(255, 255, 255);\n"
"	border: 0px soild;\n"
"	border-radius: 10px;\n"
"}\n"
"QPushButton:hover{\n"
"	background-color: rgba(40, 85, 165, 0.4);\n"
"	border-radius: 10px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: rgba(55, 55, 145, 0.7);\n"
"}"));
        QIcon icon10;
        icon10.addFile(QString::fromUtf8("App_Icon/forward_to_inbox_40dp_FILL0_wght400_GRAD0_opsz40 (1).png"), QSize(), QIcon::Normal, QIcon::Off);
        b_enviar_encuesta->setIcon(icon10);
        b_enviar_encuesta->setIconSize(QSize(90, 90));
        b_enviar_encuesta->setCheckable(false);

        horizontalLayout_15->addWidget(b_enviar_encuesta);


        verticalLayout_9->addWidget(f_epage0_dawn);

        stackedWidget_2->addWidget(e_pag_0);
        e_pag_1 = new QWidget();
        e_pag_1->setObjectName("e_pag_1");
        e_pag_1->setStyleSheet(QString::fromUtf8(""));
        verticalLayout_7 = new QVBoxLayout(e_pag_1);
        verticalLayout_7->setSpacing(5);
        verticalLayout_7->setObjectName("verticalLayout_7");
        verticalLayout_7->setContentsMargins(10, 10, 10, 10);
        f_edit_barr = new QFrame(e_pag_1);
        f_edit_barr->setObjectName("f_edit_barr");
        f_edit_barr->setMinimumSize(QSize(0, 35));
        f_edit_barr->setStyleSheet(QString::fromUtf8("background: rgba(70, 70, 70, 0.4);\n"
"border-radius: 10px;"));
        f_edit_barr->setFrameShape(QFrame::Shape::StyledPanel);
        f_edit_barr->setFrameShadow(QFrame::Shadow::Raised);
        horizontalLayout_18 = new QHBoxLayout(f_edit_barr);
        horizontalLayout_18->setSpacing(0);
        horizontalLayout_18->setObjectName("horizontalLayout_18");
        horizontalLayout_18->setContentsMargins(0, 0, 0, 0);
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Minimum);

        horizontalLayout_18->addItem(horizontalSpacer);

        b_atras_encuesta = new QPushButton(f_edit_barr);
        b_atras_encuesta->setObjectName("b_atras_encuesta");
        sizePolicy.setHeightForWidth(b_atras_encuesta->sizePolicy().hasHeightForWidth());
        b_atras_encuesta->setSizePolicy(sizePolicy);
        b_atras_encuesta->setMinimumSize(QSize(35, 0));
        b_atras_encuesta->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	background-color: rgba(40, 40, 40, 0);\n"
"	color: rgb(255, 255, 255);\n"
"	border: 0px soild;\n"
"	border-bottom-left-radius: 10px;\n"
" 	border-top-left-radius: 10px;\n"
" 	/*border-top-right-radius: 10px;\n"
"	border-bottom-right-radius: 10px;*/\n"
"}\n"
"QPushButton:hover{\n"
"	background-color: rgba(40, 85, 165, 0.4);\n"
"	border-radius: 10px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: rgba(55, 55, 145, 0.7);\n"
"}"));
        QIcon icon11;
        icon11.addFile(QString::fromUtf8("App_Icon/keyboard_return_40dp_FILL0_wght400_GRAD0_opsz40.png"), QSize(), QIcon::Normal, QIcon::Off);
        b_atras_encuesta->setIcon(icon11);

        horizontalLayout_18->addWidget(b_atras_encuesta);

        b_cancelar_encuesta = new QPushButton(f_edit_barr);
        b_cancelar_encuesta->setObjectName("b_cancelar_encuesta");
        sizePolicy.setHeightForWidth(b_cancelar_encuesta->sizePolicy().hasHeightForWidth());
        b_cancelar_encuesta->setSizePolicy(sizePolicy);
        b_cancelar_encuesta->setMinimumSize(QSize(35, 0));
        b_cancelar_encuesta->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	background-color: rgba(40, 40, 40, 0);\n"
"	color: rgb(255, 255, 255);\n"
"	border: 0px soild;\n"
"}\n"
"QPushButton:hover{\n"
"	background-color: rgba(130, 55, 90, 0.4);\n"
"	border-radius: 10px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: rgba(130, 55, 90, 1);\n"
"}"));
        QIcon icon12;
        icon12.addFile(QString::fromUtf8("App_Icon/close_small_40dp_FILL0_wght400_GRAD0_opsz40 (1).png"), QSize(), QIcon::Normal, QIcon::Off);
        b_cancelar_encuesta->setIcon(icon12);

        horizontalLayout_18->addWidget(b_cancelar_encuesta);

        b_guardar_encuesta = new QPushButton(f_edit_barr);
        b_guardar_encuesta->setObjectName("b_guardar_encuesta");
        sizePolicy.setHeightForWidth(b_guardar_encuesta->sizePolicy().hasHeightForWidth());
        b_guardar_encuesta->setSizePolicy(sizePolicy);
        b_guardar_encuesta->setMinimumSize(QSize(35, 0));
        b_guardar_encuesta->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	background-color: rgba(40, 40, 40, 0);\n"
"	color: rgb(255, 255, 255);\n"
"	border: 0px soild;\n"
"	/*border-bottom-left-radius: 10px;\n"
" 	border-top-left-radius: 10px;*/\n"
" 	border-top-right-radius: 10px;\n"
"	border-bottom-right-radius: 10px;\n"
"}\n"
"QPushButton:hover{\n"
"	background-color: rgba(40, 85, 165, 0.4);\n"
"	border-radius: 10px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: rgba(55, 55, 145, 0.7);\n"
"}"));
        QIcon icon13;
        icon13.addFile(QString::fromUtf8("App_Icon/cloud_upload_40dp_FILL0_wght400_GRAD0_opsz40 (1).png"), QSize(), QIcon::Normal, QIcon::Off);
        b_guardar_encuesta->setIcon(icon13);

        horizontalLayout_18->addWidget(b_guardar_encuesta);


        verticalLayout_7->addWidget(f_edit_barr);

        f_edit_up = new QFrame(e_pag_1);
        f_edit_up->setObjectName("f_edit_up");
        f_edit_up->setMinimumSize(QSize(0, 60));
        f_edit_up->setStyleSheet(QString::fromUtf8("background: rgba(70, 70, 70, 0.4);\n"
"border-radius: 10px;"));
        f_edit_up->setFrameShape(QFrame::Shape::StyledPanel);
        f_edit_up->setFrameShadow(QFrame::Shadow::Raised);
        horizontalLayout_19 = new QHBoxLayout(f_edit_up);
        horizontalLayout_19->setSpacing(15);
        horizontalLayout_19->setObjectName("horizontalLayout_19");
        horizontalLayout_19->setContentsMargins(10, 10, 10, 10);
        b_categoria_1 = new QPushButton(f_edit_up);
        b_categoria_1->setObjectName("b_categoria_1");
        sizePolicy.setHeightForWidth(b_categoria_1->sizePolicy().hasHeightForWidth());
        b_categoria_1->setSizePolicy(sizePolicy);
        b_categoria_1->setStyleSheet(QString::fromUtf8("QPushButton:hover{\n"
"	background-color: rgba(40, 85, 165, 0.4);\n"
"	border-radius: 10px;\n"
"}\n"
"QPushButton:checked {\n"
"    background-color: rgba(40, 85, 165, 0.7);\n"
"	border-top-left-radius: 10px;\n"
"	border-top-right-radius: 10px;\n"
"}\n"
""));
        b_categoria_1->setCheckable(true);
        b_categoria_1->setChecked(true);
        b_categoria_1->setAutoExclusive(true);

        horizontalLayout_19->addWidget(b_categoria_1);

        b_categoria_2 = new QPushButton(f_edit_up);
        b_categoria_2->setObjectName("b_categoria_2");
        sizePolicy.setHeightForWidth(b_categoria_2->sizePolicy().hasHeightForWidth());
        b_categoria_2->setSizePolicy(sizePolicy);
        b_categoria_2->setStyleSheet(QString::fromUtf8("QPushButton:hover{\n"
"	background-color: rgba(40, 85, 165, 0.4);\n"
"	border-radius: 10px;\n"
"}\n"
"QPushButton:checked {\n"
"    background-color: rgba(40, 85, 165, 0.7);\n"
"	border-top-left-radius: 10px;\n"
"	border-top-right-radius: 10px;\n"
"}\n"
""));
        b_categoria_2->setCheckable(true);
        b_categoria_2->setAutoExclusive(true);

        horizontalLayout_19->addWidget(b_categoria_2);

        b_categoria_3 = new QPushButton(f_edit_up);
        b_categoria_3->setObjectName("b_categoria_3");
        sizePolicy.setHeightForWidth(b_categoria_3->sizePolicy().hasHeightForWidth());
        b_categoria_3->setSizePolicy(sizePolicy);
        b_categoria_3->setStyleSheet(QString::fromUtf8("QPushButton:hover{\n"
"	background-color: rgba(40, 85, 165, 0.4);\n"
"	border-radius: 10px;\n"
"}\n"
"QPushButton:checked {\n"
"    background-color: rgba(40, 85, 165, 0.7);\n"
"	border-top-left-radius: 10px;\n"
"	border-top-right-radius: 10px;\n"
"}\n"
""));
        b_categoria_3->setCheckable(true);
        b_categoria_3->setAutoExclusive(true);

        horizontalLayout_19->addWidget(b_categoria_3);

        b_categoria_4 = new QPushButton(f_edit_up);
        b_categoria_4->setObjectName("b_categoria_4");
        sizePolicy.setHeightForWidth(b_categoria_4->sizePolicy().hasHeightForWidth());
        b_categoria_4->setSizePolicy(sizePolicy);
        b_categoria_4->setStyleSheet(QString::fromUtf8("QPushButton:hover{\n"
"	background-color: rgba(40, 85, 165, 0.4);\n"
"	border-radius: 10px;\n"
"}\n"
"QPushButton:checked {\n"
"    background-color: rgba(40, 85, 165, 0.7);\n"
"	border-top-left-radius: 10px;\n"
"	border-top-right-radius: 10px;\n"
"}\n"
""));
        b_categoria_4->setCheckable(true);
        b_categoria_4->setAutoExclusive(true);

        horizontalLayout_19->addWidget(b_categoria_4);


        verticalLayout_7->addWidget(f_edit_up);

        f_edit_dawn = new QFrame(e_pag_1);
        f_edit_dawn->setObjectName("f_edit_dawn");
        f_edit_dawn->setStyleSheet(QString::fromUtf8("background: rgba(70, 70, 70, 0.4);\n"
"border-radius: 10px;"));
        f_edit_dawn->setFrameShape(QFrame::Shape::StyledPanel);
        f_edit_dawn->setFrameShadow(QFrame::Shadow::Raised);
        horizontalLayout_14 = new QHBoxLayout(f_edit_dawn);
        horizontalLayout_14->setObjectName("horizontalLayout_14");
        stackedWidget_3 = new QStackedWidget(f_edit_dawn);
        stackedWidget_3->setObjectName("stackedWidget_3");
        pregunta_pag1 = new QWidget();
        pregunta_pag1->setObjectName("pregunta_pag1");
        horizontalLayout_20 = new QHBoxLayout(pregunta_pag1);
        horizontalLayout_20->setSpacing(0);
        horizontalLayout_20->setObjectName("horizontalLayout_20");
        horizontalLayout_20->setContentsMargins(0, 0, 0, 0);
        f_cat1 = new QFrame(pregunta_pag1);
        f_cat1->setObjectName("f_cat1");
        f_cat1->setFrameShape(QFrame::Shape::StyledPanel);
        f_cat1->setFrameShadow(QFrame::Shadow::Raised);
        verticalLayout_8 = new QVBoxLayout(f_cat1);
        verticalLayout_8->setSpacing(0);
        verticalLayout_8->setObjectName("verticalLayout_8");
        verticalLayout_8->setContentsMargins(0, 0, 0, 0);
        l_pregunta1_11 = new QLabel(f_cat1);
        l_pregunta1_11->setObjectName("l_pregunta1_11");
        QSizePolicy sizePolicy7(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Minimum);
        sizePolicy7.setHorizontalStretch(0);
        sizePolicy7.setVerticalStretch(0);
        sizePolicy7.setHeightForWidth(l_pregunta1_11->sizePolicy().hasHeightForWidth());
        l_pregunta1_11->setSizePolicy(sizePolicy7);
        l_pregunta1_11->setMinimumSize(QSize(0, 30));

        verticalLayout_8->addWidget(l_pregunta1_11);

        lineedit_preg1_11 = new QLineEdit(f_cat1);
        lineedit_preg1_11->setObjectName("lineedit_preg1_11");
        lineedit_preg1_11->setMinimumSize(QSize(0, 30));

        verticalLayout_8->addWidget(lineedit_preg1_11);

        l_pregunta2_11 = new QLabel(f_cat1);
        l_pregunta2_11->setObjectName("l_pregunta2_11");
        l_pregunta2_11->setMinimumSize(QSize(0, 30));

        verticalLayout_8->addWidget(l_pregunta2_11);

        lineedit_preg2_11 = new QLineEdit(f_cat1);
        lineedit_preg2_11->setObjectName("lineedit_preg2_11");
        lineedit_preg2_11->setMinimumSize(QSize(0, 30));

        verticalLayout_8->addWidget(lineedit_preg2_11);

        l_pregunta3_11 = new QLabel(f_cat1);
        l_pregunta3_11->setObjectName("l_pregunta3_11");
        l_pregunta3_11->setMinimumSize(QSize(0, 30));

        verticalLayout_8->addWidget(l_pregunta3_11);

        lineedit_preg3_11 = new QLineEdit(f_cat1);
        lineedit_preg3_11->setObjectName("lineedit_preg3_11");
        lineedit_preg3_11->setMinimumSize(QSize(0, 30));

        verticalLayout_8->addWidget(lineedit_preg3_11);

        l_pregunta4_11 = new QLabel(f_cat1);
        l_pregunta4_11->setObjectName("l_pregunta4_11");
        l_pregunta4_11->setMinimumSize(QSize(0, 30));

        verticalLayout_8->addWidget(l_pregunta4_11);

        lineedit_preg4_11 = new QLineEdit(f_cat1);
        lineedit_preg4_11->setObjectName("lineedit_preg4_11");
        lineedit_preg4_11->setMinimumSize(QSize(0, 30));

        verticalLayout_8->addWidget(lineedit_preg4_11);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        verticalLayout_8->addItem(verticalSpacer_3);


        horizontalLayout_20->addWidget(f_cat1);

        stackedWidget_3->addWidget(pregunta_pag1);
        pregunta_pag2 = new QWidget();
        pregunta_pag2->setObjectName("pregunta_pag2");
        horizontalLayout_21 = new QHBoxLayout(pregunta_pag2);
        horizontalLayout_21->setSpacing(0);
        horizontalLayout_21->setObjectName("horizontalLayout_21");
        horizontalLayout_21->setContentsMargins(0, 0, 0, 0);
        f_cat2 = new QFrame(pregunta_pag2);
        f_cat2->setObjectName("f_cat2");
        f_cat2->setFrameShape(QFrame::Shape::StyledPanel);
        f_cat2->setFrameShadow(QFrame::Shadow::Raised);
        verticalLayout_12 = new QVBoxLayout(f_cat2);
        verticalLayout_12->setSpacing(0);
        verticalLayout_12->setObjectName("verticalLayout_12");
        verticalLayout_12->setContentsMargins(0, 0, 0, 0);
        l_pregunta1_22 = new QLabel(f_cat2);
        l_pregunta1_22->setObjectName("l_pregunta1_22");
        sizePolicy7.setHeightForWidth(l_pregunta1_22->sizePolicy().hasHeightForWidth());
        l_pregunta1_22->setSizePolicy(sizePolicy7);
        l_pregunta1_22->setMinimumSize(QSize(0, 30));

        verticalLayout_12->addWidget(l_pregunta1_22);

        lineedit_preg1_22 = new QLineEdit(f_cat2);
        lineedit_preg1_22->setObjectName("lineedit_preg1_22");
        lineedit_preg1_22->setMinimumSize(QSize(0, 30));

        verticalLayout_12->addWidget(lineedit_preg1_22);

        l_pregunta2_22 = new QLabel(f_cat2);
        l_pregunta2_22->setObjectName("l_pregunta2_22");
        l_pregunta2_22->setMinimumSize(QSize(0, 30));

        verticalLayout_12->addWidget(l_pregunta2_22);

        lineedit_preg2_22 = new QLineEdit(f_cat2);
        lineedit_preg2_22->setObjectName("lineedit_preg2_22");
        lineedit_preg2_22->setMinimumSize(QSize(0, 30));

        verticalLayout_12->addWidget(lineedit_preg2_22);

        l_pregunta3_22 = new QLabel(f_cat2);
        l_pregunta3_22->setObjectName("l_pregunta3_22");
        l_pregunta3_22->setMinimumSize(QSize(0, 30));

        verticalLayout_12->addWidget(l_pregunta3_22);

        lineedit_preg3_22 = new QLineEdit(f_cat2);
        lineedit_preg3_22->setObjectName("lineedit_preg3_22");
        lineedit_preg3_22->setMinimumSize(QSize(0, 30));

        verticalLayout_12->addWidget(lineedit_preg3_22);

        l_pregunta4_22 = new QLabel(f_cat2);
        l_pregunta4_22->setObjectName("l_pregunta4_22");
        l_pregunta4_22->setMinimumSize(QSize(0, 30));

        verticalLayout_12->addWidget(l_pregunta4_22);

        lineedit_preg4_22 = new QLineEdit(f_cat2);
        lineedit_preg4_22->setObjectName("lineedit_preg4_22");
        lineedit_preg4_22->setMinimumSize(QSize(0, 30));

        verticalLayout_12->addWidget(lineedit_preg4_22);

        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        verticalLayout_12->addItem(verticalSpacer_5);


        horizontalLayout_21->addWidget(f_cat2);

        stackedWidget_3->addWidget(pregunta_pag2);
        pregunta_pag4 = new QWidget();
        pregunta_pag4->setObjectName("pregunta_pag4");
        horizontalLayout_23 = new QHBoxLayout(pregunta_pag4);
        horizontalLayout_23->setSpacing(0);
        horizontalLayout_23->setObjectName("horizontalLayout_23");
        horizontalLayout_23->setContentsMargins(0, 0, 0, 0);
        f_cat4 = new QFrame(pregunta_pag4);
        f_cat4->setObjectName("f_cat4");
        f_cat4->setFrameShape(QFrame::Shape::NoFrame);
        f_cat4->setFrameShadow(QFrame::Shadow::Raised);
        verticalLayout_14 = new QVBoxLayout(f_cat4);
        verticalLayout_14->setSpacing(0);
        verticalLayout_14->setObjectName("verticalLayout_14");
        verticalLayout_14->setContentsMargins(0, 0, 0, 0);
        l_pregunta1_44 = new QLabel(f_cat4);
        l_pregunta1_44->setObjectName("l_pregunta1_44");
        sizePolicy7.setHeightForWidth(l_pregunta1_44->sizePolicy().hasHeightForWidth());
        l_pregunta1_44->setSizePolicy(sizePolicy7);
        l_pregunta1_44->setMinimumSize(QSize(0, 30));

        verticalLayout_14->addWidget(l_pregunta1_44);

        lineedit_preg1_44 = new QLineEdit(f_cat4);
        lineedit_preg1_44->setObjectName("lineedit_preg1_44");
        lineedit_preg1_44->setMinimumSize(QSize(0, 30));

        verticalLayout_14->addWidget(lineedit_preg1_44);

        l_pregunta2_44 = new QLabel(f_cat4);
        l_pregunta2_44->setObjectName("l_pregunta2_44");
        l_pregunta2_44->setMinimumSize(QSize(0, 30));

        verticalLayout_14->addWidget(l_pregunta2_44);

        lineedit_preg2_44 = new QLineEdit(f_cat4);
        lineedit_preg2_44->setObjectName("lineedit_preg2_44");
        lineedit_preg2_44->setMinimumSize(QSize(0, 30));

        verticalLayout_14->addWidget(lineedit_preg2_44);

        l_pregunta3_44 = new QLabel(f_cat4);
        l_pregunta3_44->setObjectName("l_pregunta3_44");
        l_pregunta3_44->setMinimumSize(QSize(0, 30));

        verticalLayout_14->addWidget(l_pregunta3_44);

        lineedit_preg3_44 = new QLineEdit(f_cat4);
        lineedit_preg3_44->setObjectName("lineedit_preg3_44");
        lineedit_preg3_44->setMinimumSize(QSize(0, 30));

        verticalLayout_14->addWidget(lineedit_preg3_44);

        l_pregunta4_44 = new QLabel(f_cat4);
        l_pregunta4_44->setObjectName("l_pregunta4_44");
        l_pregunta4_44->setMinimumSize(QSize(0, 30));

        verticalLayout_14->addWidget(l_pregunta4_44);

        lineedit_preg4_44 = new QLineEdit(f_cat4);
        lineedit_preg4_44->setObjectName("lineedit_preg4_44");
        lineedit_preg4_44->setMinimumSize(QSize(0, 30));

        verticalLayout_14->addWidget(lineedit_preg4_44);

        verticalSpacer_7 = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        verticalLayout_14->addItem(verticalSpacer_7);


        horizontalLayout_23->addWidget(f_cat4);

        stackedWidget_3->addWidget(pregunta_pag4);
        pregunta_pag3 = new QWidget();
        pregunta_pag3->setObjectName("pregunta_pag3");
        horizontalLayout_22 = new QHBoxLayout(pregunta_pag3);
        horizontalLayout_22->setSpacing(0);
        horizontalLayout_22->setObjectName("horizontalLayout_22");
        horizontalLayout_22->setContentsMargins(0, 0, 0, 0);
        f_cat3 = new QFrame(pregunta_pag3);
        f_cat3->setObjectName("f_cat3");
        f_cat3->setFrameShape(QFrame::Shape::StyledPanel);
        f_cat3->setFrameShadow(QFrame::Shadow::Raised);
        verticalLayout_13 = new QVBoxLayout(f_cat3);
        verticalLayout_13->setSpacing(0);
        verticalLayout_13->setObjectName("verticalLayout_13");
        verticalLayout_13->setContentsMargins(0, 0, 0, 0);
        l_pregunta1_33 = new QLabel(f_cat3);
        l_pregunta1_33->setObjectName("l_pregunta1_33");
        sizePolicy7.setHeightForWidth(l_pregunta1_33->sizePolicy().hasHeightForWidth());
        l_pregunta1_33->setSizePolicy(sizePolicy7);
        l_pregunta1_33->setMinimumSize(QSize(0, 30));

        verticalLayout_13->addWidget(l_pregunta1_33);

        lineedit_preg1_33 = new QLineEdit(f_cat3);
        lineedit_preg1_33->setObjectName("lineedit_preg1_33");
        lineedit_preg1_33->setMinimumSize(QSize(0, 30));

        verticalLayout_13->addWidget(lineedit_preg1_33);

        l_pregunta2_33 = new QLabel(f_cat3);
        l_pregunta2_33->setObjectName("l_pregunta2_33");
        l_pregunta2_33->setMinimumSize(QSize(0, 30));

        verticalLayout_13->addWidget(l_pregunta2_33);

        lineedit_preg2_33 = new QLineEdit(f_cat3);
        lineedit_preg2_33->setObjectName("lineedit_preg2_33");
        lineedit_preg2_33->setMinimumSize(QSize(0, 30));

        verticalLayout_13->addWidget(lineedit_preg2_33);

        l_pregunta3_33 = new QLabel(f_cat3);
        l_pregunta3_33->setObjectName("l_pregunta3_33");
        l_pregunta3_33->setMinimumSize(QSize(0, 30));

        verticalLayout_13->addWidget(l_pregunta3_33);

        lineedit_preg3_33 = new QLineEdit(f_cat3);
        lineedit_preg3_33->setObjectName("lineedit_preg3_33");
        lineedit_preg3_33->setMinimumSize(QSize(0, 30));

        verticalLayout_13->addWidget(lineedit_preg3_33);

        l_pregunta4_33 = new QLabel(f_cat3);
        l_pregunta4_33->setObjectName("l_pregunta4_33");
        l_pregunta4_33->setMinimumSize(QSize(0, 30));

        verticalLayout_13->addWidget(l_pregunta4_33);

        lineedit_preg4_33 = new QLineEdit(f_cat3);
        lineedit_preg4_33->setObjectName("lineedit_preg4_33");
        lineedit_preg4_33->setMinimumSize(QSize(0, 30));

        verticalLayout_13->addWidget(lineedit_preg4_33);

        verticalSpacer_6 = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        verticalLayout_13->addItem(verticalSpacer_6);


        horizontalLayout_22->addWidget(f_cat3);

        stackedWidget_3->addWidget(pregunta_pag3);

        horizontalLayout_14->addWidget(stackedWidget_3);


        verticalLayout_7->addWidget(f_edit_dawn);

        stackedWidget_2->addWidget(e_pag_1);

        horizontalLayout_12->addWidget(stackedWidget_2);


        horizontalLayout_8->addWidget(f_pag1_encuesta);

        stackedWidget->addWidget(pag_5);

        verticalLayout_4->addWidget(stackedWidget);


        horizontalLayout_2->addWidget(f_ventanas);


        verticalLayout->addWidget(f_cuerpo_dawn);

        MainWindow->setCentralWidget(w_central);

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(5);
        tabWidget->setCurrentIndex(-1);
        stackedWidget_2->setCurrentIndex(1);
        stackedWidget_3->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        b_logo->setText(QString());
        b_perfil->setText(QString());
        b_encuesta->setText(QString());
        b_stats->setText(QString());
        b_config->setText(QString());
        label->setText(QString());
        lineEdit->setInputMask(QString());
        lineEdit->setText(QString());
        label_escuela->setText(QCoreApplication::translate("MainWindow", "Escuela :", nullptr));
        label_telefono->setText(QCoreApplication::translate("MainWindow", "Telefono :", nullptr));
        label_correo->setText(QCoreApplication::translate("MainWindow", "Correo :", nullptr));
        label_direccion->setText(QCoreApplication::translate("MainWindow", "Direccion :", nullptr));
        label_padsword->setText(QCoreApplication::translate("MainWindow", "Contrase\303\261a :", nullptr));
        lineedit_password->setText(QCoreApplication::translate("MainWindow", "1234", nullptr));
        label_img->setText(QString());
        label_nombre->setText(QCoreApplication::translate("MainWindow", "APELLIDO", nullptr));
        label_apellido->setText(QCoreApplication::translate("MainWindow", "NOMBRE ", nullptr));
        label_nick->setText(QCoreApplication::translate("MainWindow", "NICK", nullptr));
        b_ver_password->setText(QCoreApplication::translate("MainWindow", "Contrase\303\261a", nullptr));
        b_cambiar_pasworld->setText(QCoreApplication::translate("MainWindow", "Contrase\303\261a", nullptr));
        label_4->setText(QString());
        b_edit_encuesta->setText(QCoreApplication::translate("MainWindow", "Editar\n"
"Encuestas", nullptr));
        b_enviar_encuesta->setText(QCoreApplication::translate("MainWindow", "Enviar\n"
"Encuestas", nullptr));
        b_atras_encuesta->setText(QString());
        b_cancelar_encuesta->setText(QString());
        b_guardar_encuesta->setText(QString());
        b_categoria_1->setText(QCoreApplication::translate("MainWindow", "cat 1", nullptr));
        b_categoria_2->setText(QCoreApplication::translate("MainWindow", "cat2", nullptr));
        b_categoria_3->setText(QCoreApplication::translate("MainWindow", "cat 3", nullptr));
        b_categoria_4->setText(QCoreApplication::translate("MainWindow", "cat 4", nullptr));
        l_pregunta1_11->setText(QCoreApplication::translate("MainWindow", "Pregunta 1", nullptr));
        lineedit_preg1_11->setText(QString());
        l_pregunta2_11->setText(QCoreApplication::translate("MainWindow", "Pregunta 2", nullptr));
        l_pregunta3_11->setText(QCoreApplication::translate("MainWindow", "Pregunta 3", nullptr));
        l_pregunta4_11->setText(QCoreApplication::translate("MainWindow", "Pregunta 4", nullptr));
        l_pregunta1_22->setText(QCoreApplication::translate("MainWindow", "Pregunta 1", nullptr));
        lineedit_preg1_22->setText(QString());
        l_pregunta2_22->setText(QCoreApplication::translate("MainWindow", "Pregunta 2", nullptr));
        l_pregunta3_22->setText(QCoreApplication::translate("MainWindow", "Pregunta 3", nullptr));
        l_pregunta4_22->setText(QCoreApplication::translate("MainWindow", "Pregunta 4", nullptr));
        l_pregunta1_44->setText(QCoreApplication::translate("MainWindow", "Pregunta 1", nullptr));
        lineedit_preg1_44->setText(QString());
        l_pregunta2_44->setText(QCoreApplication::translate("MainWindow", "Pregunta 2", nullptr));
        l_pregunta3_44->setText(QCoreApplication::translate("MainWindow", "Pregunta 3", nullptr));
        l_pregunta4_44->setText(QCoreApplication::translate("MainWindow", "Pregunta 4", nullptr));
        l_pregunta1_33->setText(QCoreApplication::translate("MainWindow", "Pregunta 1", nullptr));
        lineedit_preg1_33->setText(QString());
        l_pregunta2_33->setText(QCoreApplication::translate("MainWindow", "Pregunta 2", nullptr));
        l_pregunta3_33->setText(QCoreApplication::translate("MainWindow", "Pregunta 3", nullptr));
        l_pregunta4_33->setText(QCoreApplication::translate("MainWindow", "Pregunta 4", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // QT_FORMCMXJOB_H
