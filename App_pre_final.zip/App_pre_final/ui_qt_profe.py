# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'qt_profegcHTXm.ui'
##
## Created by: Qt User Interface Compiler version 6.7.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel,
    QSizePolicy, QSpacerItem, QTabWidget, QVBoxLayout,
    QWidget)

class Ui_f_profe(object):
    def setupUi(self, f_profe):
        if not f_profe.objectName():
            f_profe.setObjectName(u"f_profe")
        f_profe.resize(931, 545)
        self.verticalLayout = QVBoxLayout(f_profe)
        self.verticalLayout.setSpacing(5)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(10, 10, 10, 10)
        self.f_up = QFrame(f_profe)
        self.f_up.setObjectName(u"f_up")
        self.f_up.setMinimumSize(QSize(0, 40))
        self.f_up.setMaximumSize(QSize(16777215, 60))
        self.f_up.setStyleSheet(u"	background: rgba(70, 70, 70, 0.4);\n"
"	border-radius: 10px;")
        self.f_up.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_up.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_5 = QHBoxLayout(self.f_up)
        self.horizontalLayout_5.setSpacing(10)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.horizontalLayout_5.setContentsMargins(10, 10, 10, 10)
        self.escuela_profe = QLabel(self.f_up)
        self.escuela_profe.setObjectName(u"escuela_profe")
        self.escuela_profe.setMinimumSize(QSize(200, 0))
        font = QFont()
        font.setFamilies([u"Bahnschrift SemiLight Condensed"])
        font.setPointSize(18)
        self.escuela_profe.setFont(font)
        self.escuela_profe.setStyleSheet(u"background: rgba(70, 70, 70, 0);")
        self.escuela_profe.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_5.addWidget(self.escuela_profe)

        self.horizontalSpacer_3 = QSpacerItem(568, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_5.addItem(self.horizontalSpacer_3)

        self.nombre_profe = QLabel(self.f_up)
        self.nombre_profe.setObjectName(u"nombre_profe")
        self.nombre_profe.setMinimumSize(QSize(400, 0))
        font1 = QFont()
        font1.setFamilies([u"Bahnschrift SemiLight Condensed"])
        font1.setPointSize(14)
        self.nombre_profe.setFont(font1)
        self.nombre_profe.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.nombre_profe.setMargin(5)
        self.nombre_profe.setIndent(5)

        self.horizontalLayout_5.addWidget(self.nombre_profe)

        self.perfil_profe = QLabel(self.f_up)
        self.perfil_profe.setObjectName(u"perfil_profe")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.perfil_profe.sizePolicy().hasHeightForWidth())
        self.perfil_profe.setSizePolicy(sizePolicy)
        self.perfil_profe.setMinimumSize(QSize(45, 45))
        font2 = QFont()
        font2.setFamilies([u"Bahnschrift SemiLight Condensed"])
        font2.setPointSize(16)
        self.perfil_profe.setFont(font2)
        self.perfil_profe.setPixmap(QPixmap(u"App_Icon/account_circle_40dp_FILL0_wght400_GRAD0_opsz40 (1) 70x70.png"))
        self.perfil_profe.setScaledContents(False)

        self.horizontalLayout_5.addWidget(self.perfil_profe)


        self.verticalLayout.addWidget(self.f_up)

        self.f_cuerpo = QFrame(f_profe)
        self.f_cuerpo.setObjectName(u"f_cuerpo")
        self.f_cuerpo.setStyleSheet(u"	background: rgba(70, 70, 70, 0.4);\n"
"	border-radius: 10px;")
        self.f_cuerpo.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_cuerpo.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout = QHBoxLayout(self.f_cuerpo)
        self.horizontalLayout.setSpacing(10)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(10, 10, 10, 10)
        self.f_graf_barra = QFrame(self.f_cuerpo)
        self.f_graf_barra.setObjectName(u"f_graf_barra")
        self.f_graf_barra.setFrameShape(QFrame.Shape.NoFrame)
        self.f_graf_barra.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_3 = QHBoxLayout(self.f_graf_barra)
        self.horizontalLayout_3.setSpacing(5)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(5, 5, 5, 5)
        self.tab_graf_barra = QTabWidget(self.f_graf_barra)
        self.tab_graf_barra.setObjectName(u"tab_graf_barra")
        self.tab_graf_barra.setStyleSheet(u"background: rgba(50, 50, 50, 0);")

        self.horizontalLayout_3.addWidget(self.tab_graf_barra)


        self.horizontalLayout.addWidget(self.f_graf_barra)

        self.f_graf_linea = QFrame(self.f_cuerpo)
        self.f_graf_linea.setObjectName(u"f_graf_linea")
        self.f_graf_linea.setFrameShape(QFrame.Shape.NoFrame)
        self.f_graf_linea.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.f_graf_linea)
        self.horizontalLayout_2.setSpacing(5)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(5, 5, 5, 5)
        self.tab_graf_linea = QTabWidget(self.f_graf_linea)
        self.tab_graf_linea.setObjectName(u"tab_graf_linea")
        self.tab_graf_linea.setStyleSheet(u"background: rgba(50, 50, 50, 0);")

        self.horizontalLayout_2.addWidget(self.tab_graf_linea)


        self.horizontalLayout.addWidget(self.f_graf_linea)


        self.verticalLayout.addWidget(self.f_cuerpo)

        self.f_dawn = QFrame(f_profe)
        self.f_dawn.setObjectName(u"f_dawn")
        self.f_dawn.setMinimumSize(QSize(0, 30))
        self.f_dawn.setMaximumSize(QSize(16777215, 35))
        self.f_dawn.setStyleSheet(u"	background: rgba(70, 70, 70, 0.4);\n"
"	border-radius: 10px;")
        self.f_dawn.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_dawn.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_4 = QHBoxLayout(self.f_dawn)
        self.horizontalLayout_4.setSpacing(40)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(10, 10, 10, 10)
        self.horizontalSpacer = QSpacerItem(256, 12, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer)

        self.info_0 = QLabel(self.f_dawn)
        self.info_0.setObjectName(u"info_0")
        self.info_0.setMinimumSize(QSize(80, 0))
        font3 = QFont()
        font3.setFamilies([u"Tw Cen MT Condensed"])
        font3.setPointSize(12)
        self.info_0.setFont(font3)
        self.info_0.setStyleSheet(u"background: rgba(70, 70, 70, 0);")
        self.info_0.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_4.addWidget(self.info_0)

        self.info_2 = QLabel(self.f_dawn)
        self.info_2.setObjectName(u"info_2")
        self.info_2.setMinimumSize(QSize(80, 0))
        self.info_2.setFont(font3)
        self.info_2.setStyleSheet(u"background: rgba(70, 70, 70, 0);")
        self.info_2.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_4.addWidget(self.info_2)

        self.info_1 = QLabel(self.f_dawn)
        self.info_1.setObjectName(u"info_1")
        self.info_1.setMinimumSize(QSize(80, 0))
        self.info_1.setFont(font3)
        self.info_1.setStyleSheet(u"background: rgba(70, 70, 70, 0);")
        self.info_1.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_4.addWidget(self.info_1)

        self.info_3 = QLabel(self.f_dawn)
        self.info_3.setObjectName(u"info_3")
        self.info_3.setMinimumSize(QSize(80, 0))
        self.info_3.setFont(font3)
        self.info_3.setStyleSheet(u"background: rgba(70, 70, 70, 0);")
        self.info_3.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_4.addWidget(self.info_3)

        self.info_4 = QLabel(self.f_dawn)
        self.info_4.setObjectName(u"info_4")
        self.info_4.setMinimumSize(QSize(80, 0))
        self.info_4.setFont(font3)
        self.info_4.setStyleSheet(u"background: rgba(70, 70, 70, 0);	")
        self.info_4.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_4.addWidget(self.info_4)

        self.horizontalSpacer_2 = QSpacerItem(256, 12, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_2)


        self.verticalLayout.addWidget(self.f_dawn)


        self.retranslateUi(f_profe)

        self.tab_graf_barra.setCurrentIndex(-1)
        self.tab_graf_linea.setCurrentIndex(-1)


        QMetaObject.connectSlotsByName(f_profe)
    # setupUi

    def retranslateUi(self, f_profe):
        f_profe.setWindowTitle(QCoreApplication.translate("f_profe", u"Frame", None))
        self.escuela_profe.setText(QCoreApplication.translate("f_profe", u"Escuela ...", None))
        self.nombre_profe.setText(QCoreApplication.translate("f_profe", u"Nombre", None))
        self.perfil_profe.setText("")
        self.info_0.setText(QCoreApplication.translate("f_profe", u"dato_1", None))
        self.info_2.setText(QCoreApplication.translate("f_profe", u"dato_2", None))
        self.info_1.setText(QCoreApplication.translate("f_profe", u"dato_0", None))
        self.info_3.setText(QCoreApplication.translate("f_profe", u"dato_3", None))
        self.info_4.setText(QCoreApplication.translate("f_profe", u"dato_4", None))
    # retranslateUi

