# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'qt_loginXRvTEu.ui'
##
## Created by: Qt User Interface Compiler version 6.7.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QSizePolicy, QSpacerItem,
    QStackedWidget, QVBoxLayout, QWidget)

class Ui_Logni(object):
    def setupUi(self, Logni):
        if not Logni.objectName():
            Logni.setObjectName(u"Logni")
        Logni.resize(420, 600)
        Logni.setMinimumSize(QSize(420, 420))
        Logni.setMaximumSize(QSize(420, 600))
        self.verticalLayout = QVBoxLayout(Logni)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.stackedWidget = QStackedWidget(Logni)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.pag_0 = QWidget()
        self.pag_0.setObjectName(u"pag_0")
        self.verticalLayout_5 = QVBoxLayout(self.pag_0)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.f_login = QFrame(self.pag_0)
        self.f_login.setObjectName(u"f_login")
        self.f_login.setMaximumSize(QSize(16777215, 550))
        self.f_login.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_login.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_2 = QVBoxLayout(self.f_login)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.f_encabezado = QFrame(self.f_login)
        self.f_encabezado.setObjectName(u"f_encabezado")
        self.f_encabezado.setFrameShape(QFrame.Shape.NoFrame)
        self.f_encabezado.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_4 = QVBoxLayout(self.f_encabezado)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.label_logo = QLabel(self.f_encabezado)
        self.label_logo.setObjectName(u"label_logo")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_logo.sizePolicy().hasHeightForWidth())
        self.label_logo.setSizePolicy(sizePolicy)
        self.label_logo.setMinimumSize(QSize(100, 100))
        self.label_logo.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_4.addWidget(self.label_logo, 0, Qt.AlignmentFlag.AlignHCenter)

        self.label_UNP = QLabel(self.f_encabezado)
        self.label_UNP.setObjectName(u"label_UNP")

        self.verticalLayout_4.addWidget(self.label_UNP, 0, Qt.AlignmentFlag.AlignHCenter)

        self.label_GMA = QLabel(self.f_encabezado)
        self.label_GMA.setObjectName(u"label_GMA")

        self.verticalLayout_4.addWidget(self.label_GMA, 0, Qt.AlignmentFlag.AlignHCenter)

        self.verticalSpacer_2 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_4.addItem(self.verticalSpacer_2)


        self.verticalLayout_2.addWidget(self.f_encabezado)

        self.f_entrada_datos = QFrame(self.f_login)
        self.f_entrada_datos.setObjectName(u"f_entrada_datos")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.f_entrada_datos.sizePolicy().hasHeightForWidth())
        self.f_entrada_datos.setSizePolicy(sizePolicy1)
        self.f_entrada_datos.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_entrada_datos.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_3 = QVBoxLayout(self.f_entrada_datos)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.label_user = QLabel(self.f_entrada_datos)
        self.label_user.setObjectName(u"label_user")
        self.label_user.setMaximumSize(QSize(16777215, 39))

        self.verticalLayout_3.addWidget(self.label_user)

        self.lineedit_user_log = QLineEdit(self.f_entrada_datos)
        self.lineedit_user_log.setObjectName(u"lineedit_user_log")
        self.lineedit_user_log.setMinimumSize(QSize(0, 30))

        self.verticalLayout_3.addWidget(self.lineedit_user_log)

        self.label_password = QLabel(self.f_entrada_datos)
        self.label_password.setObjectName(u"label_password")
        self.label_password.setMaximumSize(QSize(16777215, 30))

        self.verticalLayout_3.addWidget(self.label_password)

        self.lineedit_password_log = QLineEdit(self.f_entrada_datos)
        self.lineedit_password_log.setObjectName(u"lineedit_password_log")
        self.lineedit_password_log.setMinimumSize(QSize(0, 30))

        self.verticalLayout_3.addWidget(self.lineedit_password_log)


        self.verticalLayout_2.addWidget(self.f_entrada_datos, 0, Qt.AlignmentFlag.AlignHCenter)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_2.addItem(self.verticalSpacer)

        self.f_botones = QFrame(self.f_login)
        self.f_botones.setObjectName(u"f_botones")
        sizePolicy1.setHeightForWidth(self.f_botones.sizePolicy().hasHeightForWidth())
        self.f_botones.setSizePolicy(sizePolicy1)
        self.f_botones.setMinimumSize(QSize(300, 50))
        self.f_botones.setFrameShape(QFrame.Shape.NoFrame)
        self.f_botones.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout = QHBoxLayout(self.f_botones)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.b_login = QPushButton(self.f_botones)
        self.b_login.setObjectName(u"b_login")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.b_login.sizePolicy().hasHeightForWidth())
        self.b_login.setSizePolicy(sizePolicy2)
        self.b_login.setMinimumSize(QSize(0, 40))

        self.horizontalLayout.addWidget(self.b_login)

        self.b_register = QPushButton(self.f_botones)
        self.b_register.setObjectName(u"b_register")
        sizePolicy2.setHeightForWidth(self.b_register.sizePolicy().hasHeightForWidth())
        self.b_register.setSizePolicy(sizePolicy2)
        self.b_register.setMinimumSize(QSize(0, 40))

        self.horizontalLayout.addWidget(self.b_register)


        self.verticalLayout_2.addWidget(self.f_botones, 0, Qt.AlignmentFlag.AlignHCenter)


        self.verticalLayout_5.addWidget(self.f_login)

        self.stackedWidget.addWidget(self.pag_0)
        self.pag_1 = QWidget()
        self.pag_1.setObjectName(u"pag_1")
        self.verticalLayout_9 = QVBoxLayout(self.pag_1)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.f_rgister = QFrame(self.pag_1)
        self.f_rgister.setObjectName(u"f_rgister")
        self.f_rgister.setMaximumSize(QSize(16777215, 550))
        self.f_rgister.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_rgister.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_6 = QVBoxLayout(self.f_rgister)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.f_encabezado_r = QFrame(self.f_rgister)
        self.f_encabezado_r.setObjectName(u"f_encabezado_r")
        self.f_encabezado_r.setFrameShape(QFrame.Shape.NoFrame)
        self.f_encabezado_r.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_7 = QVBoxLayout(self.f_encabezado_r)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.label_logo_r = QLabel(self.f_encabezado_r)
        self.label_logo_r.setObjectName(u"label_logo_r")
        sizePolicy.setHeightForWidth(self.label_logo_r.sizePolicy().hasHeightForWidth())
        self.label_logo_r.setSizePolicy(sizePolicy)
        self.label_logo_r.setMinimumSize(QSize(100, 100))
        self.label_logo_r.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_7.addWidget(self.label_logo_r, 0, Qt.AlignmentFlag.AlignHCenter)

        self.label_UNP_r = QLabel(self.f_encabezado_r)
        self.label_UNP_r.setObjectName(u"label_UNP_r")

        self.verticalLayout_7.addWidget(self.label_UNP_r, 0, Qt.AlignmentFlag.AlignHCenter)

        self.label_GMA_r = QLabel(self.f_encabezado_r)
        self.label_GMA_r.setObjectName(u"label_GMA_r")

        self.verticalLayout_7.addWidget(self.label_GMA_r, 0, Qt.AlignmentFlag.AlignHCenter)

        self.verticalSpacer_r = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_7.addItem(self.verticalSpacer_r)


        self.verticalLayout_6.addWidget(self.f_encabezado_r)

        self.f_entrada_datos_r = QFrame(self.f_rgister)
        self.f_entrada_datos_r.setObjectName(u"f_entrada_datos_r")
        sizePolicy1.setHeightForWidth(self.f_entrada_datos_r.sizePolicy().hasHeightForWidth())
        self.f_entrada_datos_r.setSizePolicy(sizePolicy1)
        self.f_entrada_datos_r.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_entrada_datos_r.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_8 = QVBoxLayout(self.f_entrada_datos_r)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.label_user_r = QLabel(self.f_entrada_datos_r)
        self.label_user_r.setObjectName(u"label_user_r")
        self.label_user_r.setMaximumSize(QSize(16777215, 39))

        self.verticalLayout_8.addWidget(self.label_user_r)

        self.lineedit_user_reg = QLineEdit(self.f_entrada_datos_r)
        self.lineedit_user_reg.setObjectName(u"lineedit_user_reg")
        self.lineedit_user_reg.setMinimumSize(QSize(0, 30))

        self.verticalLayout_8.addWidget(self.lineedit_user_reg)

        self.label_password_r = QLabel(self.f_entrada_datos_r)
        self.label_password_r.setObjectName(u"label_password_r")
        self.label_password_r.setMaximumSize(QSize(16777215, 30))

        self.verticalLayout_8.addWidget(self.label_password_r)

        self.lineedit_password_reg = QLineEdit(self.f_entrada_datos_r)
        self.lineedit_password_reg.setObjectName(u"lineedit_password_reg")
        self.lineedit_password_reg.setMinimumSize(QSize(0, 30))

        self.verticalLayout_8.addWidget(self.lineedit_password_reg)

        self.label_confirmes = QLabel(self.f_entrada_datos_r)
        self.label_confirmes.setObjectName(u"label_confirmes")

        self.verticalLayout_8.addWidget(self.label_confirmes)

        self.lineedit_confirmed = QLineEdit(self.f_entrada_datos_r)
        self.lineedit_confirmed.setObjectName(u"lineedit_confirmed")
        self.lineedit_confirmed.setMinimumSize(QSize(0, 30))

        self.verticalLayout_8.addWidget(self.lineedit_confirmed)


        self.verticalLayout_6.addWidget(self.f_entrada_datos_r, 0, Qt.AlignmentFlag.AlignHCenter)

        self.verticalSpacer_4 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_6.addItem(self.verticalSpacer_4)

        self.f_botones_r = QFrame(self.f_rgister)
        self.f_botones_r.setObjectName(u"f_botones_r")
        sizePolicy1.setHeightForWidth(self.f_botones_r.sizePolicy().hasHeightForWidth())
        self.f_botones_r.setSizePolicy(sizePolicy1)
        self.f_botones_r.setMinimumSize(QSize(300, 50))
        self.f_botones_r.setFrameShape(QFrame.Shape.NoFrame)
        self.f_botones_r.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.f_botones_r)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.b_volver = QPushButton(self.f_botones_r)
        self.b_volver.setObjectName(u"b_volver")
        sizePolicy2.setHeightForWidth(self.b_volver.sizePolicy().hasHeightForWidth())
        self.b_volver.setSizePolicy(sizePolicy2)
        self.b_volver.setMinimumSize(QSize(0, 40))

        self.horizontalLayout_2.addWidget(self.b_volver)

        self.b_register_r = QPushButton(self.f_botones_r)
        self.b_register_r.setObjectName(u"b_register_r")
        sizePolicy2.setHeightForWidth(self.b_register_r.sizePolicy().hasHeightForWidth())
        self.b_register_r.setSizePolicy(sizePolicy2)
        self.b_register_r.setMinimumSize(QSize(0, 40))

        self.horizontalLayout_2.addWidget(self.b_register_r)


        self.verticalLayout_6.addWidget(self.f_botones_r, 0, Qt.AlignmentFlag.AlignHCenter)


        self.verticalLayout_9.addWidget(self.f_rgister)

        self.stackedWidget.addWidget(self.pag_1)

        self.verticalLayout.addWidget(self.stackedWidget)


        self.retranslateUi(Logni)

        self.stackedWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(Logni)
    # setupUi

    def retranslateUi(self, Logni):
        Logni.setWindowTitle(QCoreApplication.translate("Logni", u"Form", None))
        self.label_logo.setText(QCoreApplication.translate("Logni", u"IMAGEN", None))
        self.label_UNP.setText(QCoreApplication.translate("Logni", u"UNIVERSIDAD NORORIENTAL PRIVADA", None))
        self.label_GMA.setText(QCoreApplication.translate("Logni", u"GRAN MARISCAL DE AYACUCHO", None))
        self.label_user.setText(QCoreApplication.translate("Logni", u"User :", None))
        self.label_password.setText(QCoreApplication.translate("Logni", u"Passwprd :", None))
        self.b_login.setText(QCoreApplication.translate("Logni", u"LOGIN ", None))
        self.b_register.setText(QCoreApplication.translate("Logni", u"REGISTER", None))
        self.label_logo_r.setText(QCoreApplication.translate("Logni", u"IMAGEN", None))
        self.label_UNP_r.setText(QCoreApplication.translate("Logni", u"UNIVERSIDAD NORORIENTAL PRIVADA", None))
        self.label_GMA_r.setText(QCoreApplication.translate("Logni", u"GRAN MARISCAL DE AYACUCHO", None))
        self.label_user_r.setText(QCoreApplication.translate("Logni", u"User :", None))
        self.label_password_r.setText(QCoreApplication.translate("Logni", u"Passwprd :", None))
        self.label_confirmes.setText(QCoreApplication.translate("Logni", u"Password :", None))
        self.b_volver.setText(QCoreApplication.translate("Logni", u"VOLVER", None))
        self.b_register_r.setText(QCoreApplication.translate("Logni", u"REGISTRAR", None))
    # retranslateUi

