from email.message import EmailMessage
#from google_form import linkF
import smtplib
from BDconsultas import *

#link=linkF

link="hola"
remitente="bot.ugma@gmail.com"

def correos():
    materias=consultaMaterias()
    for i in range(len(materias)):
        listado=consultaCorreosPorMateria(materias[i][0])
        for i in range(len(listado)):
            send_email(listado[i][0],listado[i][1])

def send_email(nombre, destino):
    msg="Hola, "+nombre+",Soy el bot de frank :D responde la siguiente encuesta "
    #msg="Hola "+nombre+", ingresa a este link para responder la encuesta sobre tu profesor: "+link;
    email=EmailMessage()
    email["From"]=remitente
    email["To"]=destino
    email["Subject"]="Encuesta de profesores"
    email.set_content(msg)
    smtp= smtplib.SMTP_SSL('smtp.gmail.com')
    smtp.login(remitente, "zgzm vvlw cctf kyjo")
    smtp.sendmail(remitente,destino,email.as_string())
    smtp.quit()

# def main():
#     correos()
    
# if __name__=="__main__":
#     main()