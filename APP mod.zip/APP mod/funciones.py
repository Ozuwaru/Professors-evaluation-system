import sys
from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
from ui_qt_perfil import *
from PySide6.QtCore import Qt
from BDconsultas import *
from matplotlib.ticker import MultipleLocator

class Perfil(QFrame):
    def __init__(self, app_instance,name,idP,esc,cedula):
        super(Perfil, self).__init__()
        self.ui = Ui_f_shear_profe()   
        self.ui.setupUi(self)
        self.nombre=name
        self.id=idP
        self.escuela=esc
        self.cedula=cedula
        
        # REFERENCIA A LA APP MAIN
        self.app_instance = app_instance
        self.informacion()
        # CONECCCIONES DE PERFILES DE BUSQUEDA
        self.ui.stats_profe.clicked.connect(self.nuevaEstadisticas)
        
        #self.ui.b_stat_profe.cliked.connect(self.nuevaEstadisticas)
        
    # INICIALIZAION DE DATOS
    def informacion(self):
        self.ui.s_nombre_profe.setText(self.nombre)
        self.ui.s_escuela_profe.setText(self.escuela)
        #self.ui.img_profe.pixmap(img) 
        
    # FUNCION PARA AGREGAR UNA TAB DEL PERFIL
    def nuevaEstadisticas(self):
        self.app_instance.nuevaEstadisticas(self.id)

class Busqueda:
    #aqui se lee la info desde la BDD buscando coincidencias
    def __init__(self,app_instance,texto):
        self.instancia=app_instance
        self.nombre=texto
        self.lectura()
        
    def lectura(self):
        self.lista=consultaNombre(self.nombre)
    
    def recuadro(self):
        recuadros=[]
        for i in range(len(self.lista)):
           aux=Perfil(self.instancia,self.lista[i][1],self.lista[i][0],self.lista[i][2],self.lista[i][3])
           recuadros.append(aux)
        return recuadros

class Graficas:
    def ejes(self,lista,graf,materia):
        self.x_labels,self.y=[],[]
        #Si es grafica de encuestas por materia
        if(graf==0): 
            # if(materia!=0):
            for i in range(len(lista)):
                if(lista[i][1]==materia):
                    self.x_labels.append(lista[i][2])
                    self.y.append(float(lista[i][3]))
            # else:
            #     for i in range(len(lista)):
            #         self.x_labels.append(lista[i][2])
            #         self.y.append(float(lista[i][3]))
            self.x = range(len(self.x_labels))
        else:
            for i in range(len(lista)):
                self.x_labels.append(lista[i][0])
                self.y.append(float(lista[i][1]))
            self.x = range(len(self.x_labels))
        
    def g_barras(self,lista,name_x,name_y,graf,materia):
        self.ejes(lista,graf,materia)
        fig, ax = plt.subplots()
        ax.bar(self.x,self.y)
        ax.set_xlabel(name_x)
        ax.set_ylabel(name_y)
        ax.set_xticks(self.x)
        if(graf!=0):
            ax.set_xticklabels(self.x_labels)
        ax.yaxis.set_major_locator(MultipleLocator(0.5))
        ax.set_ylim(0, 5)
        return fig

    def g_lineas(self,lista,name_x,name_y,graf,materia):
        self.ejes(lista,graf,materia)
        fig, ax = plt.subplots()
        ax.plot(self.x,self.y,marker='o')
        ax.set_xlabel(name_x)
        ax.set_ylabel(name_y)
        ax.set_xticks(self.x)
        if(graf!=0):
            ax.set_xticklabels(self.x_labels)
        ax.yaxis.set_major_locator(MultipleLocator(0.5))
        ax.set_ylim(0, 5)
        return fig
        
class GraphicTab(QWidget):
    def __init__(self,tipo,idP,graf,materia):
        super().__init__()
        self.graficas=Graficas()
        self.tipo=tipo 
        self.id=idP 
        self.graf=graf 
        self.materia=materia 
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()
        self.setLayout(layout)
        #si es grafico de encuestas
        if(self.graf==0):
            lista=obtenerPromedioPorProfesor(self.id,self.graf)
            if(self.tipo==0):
                fig = self.graficas.g_barras(lista, "Pregunta", "Puntaje",self.graf,self.materia)
            elif(self.tipo==1):
                fig = self.graficas.g_lineas(lista, "Pregunta", "Puntaje",self.graf,self.materia)
        else:
            lista=obtenerPromedioPorProfesor(self.id,self.graf)
            if(self.tipo==0):
                fig = self.graficas.g_barras(lista, "Materia", "Puntaje",self.graf,self.materia)
            elif(self.tipo==1):
                fig = self.graficas.g_lineas(lista, "Materia", "Puntaje",self.graf,self.materia)
        canvas = FigureCanvas(fig)
        layout.addWidget(canvas)
        self.setGeometry(100, 100, 600, 400)
        if(self.tipo==0):
            self.setWindowTitle('Gráfico de Barras en QWidget')
        elif(self.tipo==1):
            self.setWindowTitle('Gráfico de Líneas en QWidget')
        self.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = GraphicTab(0,"1",0,1)
    sys.exit(app.exec_())