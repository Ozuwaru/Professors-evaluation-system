# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'qt_formSUXsHM.ui'
##
## Created by: Qt User Interface Compiler version 6.7.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QGridLayout, QHBoxLayout,
    QLabel, QLineEdit, QMainWindow, QPushButton,
    QScrollArea, QSizePolicy, QSpacerItem, QStackedWidget,
    QTabWidget, QVBoxLayout, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(820, 420)
        MainWindow.setMinimumSize(QSize(820, 420))
        MainWindow.setStyleSheet(u"")
        self.w_central = QWidget(MainWindow)
        self.w_central.setObjectName(u"w_central")
        self.w_central.setStyleSheet(u"background-color: rgb(65, 65, 65); \n"
"")
        self.verticalLayout = QVBoxLayout(self.w_central)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.f_cuerpo_up = QFrame(self.w_central)
        self.f_cuerpo_up.setObjectName(u"f_cuerpo_up")
        self.f_cuerpo_up.setMaximumSize(QSize(16777215, 40))
        self.f_cuerpo_up.setStyleSheet(u"background-color: rgb(45, 45, 45); \n"
"")
        self.f_cuerpo_up.setFrameShape(QFrame.Shape.NoFrame)
        self.horizontalLayout = QHBoxLayout(self.f_cuerpo_up)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.f_logo = QFrame(self.f_cuerpo_up)
        self.f_logo.setObjectName(u"f_logo")
        self.f_logo.setMaximumSize(QSize(50, 40))
        self.f_logo.setStyleSheet(u"background-color: rgb(170, 85, 255)")
        self.f_logo.setFrameShape(QFrame.Shape.NoFrame)
        self.horizontalLayout_3 = QHBoxLayout(self.f_logo)
        self.horizontalLayout_3.setSpacing(0)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.b_logo = QPushButton(self.f_logo)
        self.b_logo.setObjectName(u"b_logo")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.b_logo.sizePolicy().hasHeightForWidth())
        self.b_logo.setSizePolicy(sizePolicy)
        self.b_logo.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: 0px solid;\n"
"opacity: 0.5;")
        icon = QIcon()
        icon.addFile(u"../VS Code/PROYECTO QT PY/APP/images/images/PyDracula.png", QSize(), QIcon.Normal, QIcon.Off)
        self.b_logo.setIcon(icon)
        self.b_logo.setIconSize(QSize(32, 32))
        self.b_logo.setCheckable(False)

        self.horizontalLayout_3.addWidget(self.b_logo)


        self.horizontalLayout.addWidget(self.f_logo)

        self.f_barra = QFrame(self.f_cuerpo_up)
        self.f_barra.setObjectName(u"f_barra")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.f_barra.sizePolicy().hasHeightForWidth())
        self.f_barra.setSizePolicy(sizePolicy1)
        self.f_barra.setMaximumSize(QSize(4000, 40))
        self.f_barra.setFrameShape(QFrame.Shape.NoFrame)
        self.horizontalLayout_5 = QHBoxLayout(self.f_barra)
        self.horizontalLayout_5.setSpacing(0)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.horizontalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.horizontalSpacer_5 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_5.addItem(self.horizontalSpacer_5)

        self.f_perfil = QFrame(self.f_barra)
        self.f_perfil.setObjectName(u"f_perfil")
        self.f_perfil.setMaximumSize(QSize(60, 40))
        self.f_perfil.setFrameShape(QFrame.Shape.NoFrame)
        self.horizontalLayout_6 = QHBoxLayout(self.f_perfil)
        self.horizontalLayout_6.setSpacing(0)
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.horizontalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.b_perfil = QPushButton(self.f_perfil)
        self.b_perfil.setObjectName(u"b_perfil")
        self.b_perfil.setMinimumSize(QSize(40, 40))
        self.b_perfil.setMaximumSize(QSize(40, 40))
        self.b_perfil.setStyleSheet(u"QPushButton{\n"
"	color: rgb(255, 255, 255);\n"
"	background-color: rgb(45, 45, 45);\n"
"	border: 0px soild\n"
"}\n"
"\n"
"QPushButton:hover{\n"
"	background-color: rgb(170, 85, 255);\n"
"}\n"
"")
        icon1 = QIcon()
        icon1.addFile(u"../VS Code/PROYECTO QT PY/APP/images/icons/cil-people.png", QSize(), QIcon.Normal, QIcon.Off)
        self.b_perfil.setIcon(icon1)
        self.b_perfil.setCheckable(False)

        self.horizontalLayout_6.addWidget(self.b_perfil)


        self.horizontalLayout_5.addWidget(self.f_perfil, 0, Qt.AlignmentFlag.AlignRight)


        self.horizontalLayout.addWidget(self.f_barra)


        self.verticalLayout.addWidget(self.f_cuerpo_up)

        self.f_cuerpo_dawn = QFrame(self.w_central)
        self.f_cuerpo_dawn.setObjectName(u"f_cuerpo_dawn")
        self.f_cuerpo_dawn.setFrameShape(QFrame.Shape.NoFrame)
        self.horizontalLayout_2 = QHBoxLayout(self.f_cuerpo_dawn)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.f_m_icon = QFrame(self.f_cuerpo_dawn)
        self.f_m_icon.setObjectName(u"f_m_icon")
        self.f_m_icon.setMinimumSize(QSize(50, 0))
        self.f_m_icon.setMaximumSize(QSize(50, 4000))
        self.f_m_icon.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.f_m_icon.setStyleSheet(u"background-color: rgb(45, 45, 45); ")
        self.f_m_icon.setFrameShape(QFrame.Shape.NoFrame)
        self.verticalLayout_2 = QVBoxLayout(self.f_m_icon)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.b_encuesta = QPushButton(self.f_m_icon)
        self.b_encuesta.setObjectName(u"b_encuesta")
        self.b_encuesta.setMinimumSize(QSize(50, 40))
        self.b_encuesta.setStyleSheet(u"QPushButton{\n"
"	color: rgb(255, 255, 255);\n"
"	background-color: rgb(45, 45, 45);\n"
"	border: 0px soild\n"
"}\n"
"QPushButton:hover{\n"
"	background-color: rgb(170, 85, 255);\n"
"}\n"
"")
        icon2 = QIcon()
        icon2.addFile(u"../VS Code/PROYECTO QT PY/APP/images/icons/cil-notes.png", QSize(), QIcon.Normal, QIcon.Off)
        self.b_encuesta.setIcon(icon2)
        self.b_encuesta.setCheckable(True)
        self.b_encuesta.setAutoExclusive(True)
        self.b_encuesta.setAutoDefault(False)

        self.verticalLayout_2.addWidget(self.b_encuesta)

        self.b_shear = QPushButton(self.f_m_icon)
        self.b_shear.setObjectName(u"b_shear")
        self.b_shear.setMinimumSize(QSize(50, 40))
        self.b_shear.setMouseTracking(True)
        self.b_shear.setStyleSheet(u"QPushButton{\n"
"	color: rgb(255, 255, 255);\n"
"	background-color: rgb(45, 45, 45);\n"
"	border: 0px soild\n"
"}\n"
"QPushButton:hover{\n"
"	background-color: rgb(170, 85, 255);\n"
"}\n"
"")
        icon3 = QIcon()
        icon3.addFile(u"../VS Code/PROYECTO QT PY/APP/images/icons/cil-magnifying-glass.png", QSize(), QIcon.Normal, QIcon.Off)
        self.b_shear.setIcon(icon3)
        self.b_shear.setCheckable(True)
        self.b_shear.setAutoExclusive(True)

        self.verticalLayout_2.addWidget(self.b_shear)

        self.b_stats = QPushButton(self.f_m_icon)
        self.b_stats.setObjectName(u"b_stats")
        self.b_stats.setMinimumSize(QSize(50, 40))
        self.b_stats.setStyleSheet(u"QPushButton{\n"
"	color: rgb(255, 255, 255);\n"
"	background-color: rgb(45, 45, 45);\n"
"	border: 0px soild\n"
"}\n"
"QPushButton:hover{\n"
"	background-color: rgb(170, 85, 255);\n"
"}\n"
"")
        icon4 = QIcon()
        icon4.addFile(u"../VS Code/PROYECTO QT PY/APP/images/icons/cil-chart-line.png", QSize(), QIcon.Normal, QIcon.Off)
        self.b_stats.setIcon(icon4)
        self.b_stats.setCheckable(True)
        self.b_stats.setAutoExclusive(True)

        self.verticalLayout_2.addWidget(self.b_stats)

        self.verticalSpacer = QSpacerItem(20, 257, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_2.addItem(self.verticalSpacer)

        self.b_config = QPushButton(self.f_m_icon)
        self.b_config.setObjectName(u"b_config")
        self.b_config.setMinimumSize(QSize(50, 40))
        self.b_config.setStyleSheet(u"QPushButton{\n"
"	color: rgb(255, 255, 255);\n"
"	background-color: rgb(45, 45, 45);\n"
"	border: 0px soild\n"
"}\n"
"\n"
"QPushButton:hover{\n"
"	background-color: rgb(170, 85, 255);\n"
"}\n"
"")
        icon5 = QIcon()
        icon5.addFile(u"../VS Code/PROYECTO QT PY/APP/images/icons/cil-settings.png", QSize(), QIcon.Normal, QIcon.Off)
        self.b_config.setIcon(icon5)
        self.b_config.setCheckable(True)
        self.b_config.setAutoExclusive(True)

        self.verticalLayout_2.addWidget(self.b_config)


        self.horizontalLayout_2.addWidget(self.f_m_icon)

        self.f_ventanas = QFrame(self.f_cuerpo_dawn)
        self.f_ventanas.setObjectName(u"f_ventanas")
        sizePolicy1.setHeightForWidth(self.f_ventanas.sizePolicy().hasHeightForWidth())
        self.f_ventanas.setSizePolicy(sizePolicy1)
        self.f_ventanas.setFrameShape(QFrame.Shape.NoFrame)
        self.verticalLayout_4 = QVBoxLayout(self.f_ventanas)
        self.verticalLayout_4.setSpacing(0)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.stackedWidget = QStackedWidget(self.f_ventanas)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.stackedWidget.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.pag_0 = QWidget()
        self.pag_0.setObjectName(u"pag_0")
        self.horizontalLayout_10 = QHBoxLayout(self.pag_0)
        self.horizontalLayout_10.setSpacing(0)
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.horizontalLayout_10.setContentsMargins(0, 0, 0, 0)
        self.f_pag0_inicio = QFrame(self.pag_0)
        self.f_pag0_inicio.setObjectName(u"f_pag0_inicio")
        self.f_pag0_inicio.setFrameShape(QFrame.Shape.NoFrame)
        self.verticalLayout_6 = QVBoxLayout(self.f_pag0_inicio)
        self.verticalLayout_6.setSpacing(0)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.label = QLabel(self.f_pag0_inicio)
        self.label.setObjectName(u"label")
        self.label.setMinimumSize(QSize(32, 32))
        self.label.setPixmap(QPixmap(u"../VS Code/PROYECTO QT PY/APP/images/images/ugma.png"))

        self.verticalLayout_6.addWidget(self.label, 0, Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignVCenter)


        self.horizontalLayout_10.addWidget(self.f_pag0_inicio)

        self.stackedWidget.addWidget(self.pag_0)
        self.pag_1 = QWidget()
        self.pag_1.setObjectName(u"pag_1")
        self.horizontalLayout_4 = QHBoxLayout(self.pag_1)
        self.horizontalLayout_4.setSpacing(0)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.f_pag4_shear = QFrame(self.pag_1)
        self.f_pag4_shear.setObjectName(u"f_pag4_shear")
        self.f_pag4_shear.setFrameShape(QFrame.Shape.NoFrame)
        self.f_pag4_shear.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_3 = QVBoxLayout(self.f_pag4_shear)
        self.verticalLayout_3.setSpacing(6)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 9, 0, 9)
        self.f_shear_up = QFrame(self.f_pag4_shear)
        self.f_shear_up.setObjectName(u"f_shear_up")
        self.f_shear_up.setMaximumSize(QSize(16777215, 40))
        self.f_shear_up.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.f_shear_up.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_shear_up.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_11 = QHBoxLayout(self.f_shear_up)
        self.horizontalLayout_11.setSpacing(0)
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.horizontalLayout_11.setContentsMargins(0, 0, 0, 0)
        self.b_shear_2 = QPushButton(self.f_shear_up)
        self.b_shear_2.setObjectName(u"b_shear_2")
        self.b_shear_2.setMinimumSize(QSize(50, 35))
        self.b_shear_2.setMaximumSize(QSize(50, 35))
        self.b_shear_2.setMouseTracking(True)
        self.b_shear_2.setStyleSheet(u"/*QPushButton{\n"
"	color: rgb(255, 255, 255);\n"
"	background-color: rgb(45, 45, 45);\n"
"	border: 0px soild\n"
"}*/\n"
"QPushButton:hover{\n"
"	background-color: rgb(170, 85, 255);\n"
"}\n"
"")
        self.b_shear_2.setIcon(icon3)
        self.b_shear_2.setCheckable(False)
        self.b_shear_2.setAutoExclusive(False)

        self.horizontalLayout_11.addWidget(self.b_shear_2)

        self.lineEdit = QLineEdit(self.f_shear_up)
        self.lineEdit.setObjectName(u"lineEdit")
        self.lineEdit.setMinimumSize(QSize(300, 35))
        self.lineEdit.setMaximumSize(QSize(400, 35))
        self.lineEdit.setEchoMode(QLineEdit.EchoMode.Normal)
        self.lineEdit.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lineEdit.setCursorMoveStyle(Qt.CursorMoveStyle.LogicalMoveStyle)

        self.horizontalLayout_11.addWidget(self.lineEdit)


        self.verticalLayout_3.addWidget(self.f_shear_up, 0, Qt.AlignmentFlag.AlignHCenter)

        self.f_shear_dawn = QFrame(self.f_pag4_shear)
        self.f_shear_dawn.setObjectName(u"f_shear_dawn")
        self.f_shear_dawn.setFrameShape(QFrame.Shape.NoFrame)
        self.f_shear_dawn.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_5 = QVBoxLayout(self.f_shear_dawn)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.scrollArea = QScrollArea(self.f_shear_dawn)
        self.scrollArea.setObjectName(u"scrollArea")
        self.scrollArea.setWidgetResizable(True)
        self.scrollAreaContents = QWidget()
        self.scrollAreaContents.setObjectName(u"scrollAreaContents")
        self.scrollAreaContents.setGeometry(QRect(0, 0, 829, 427))
        self.verticalLayout_10 = QVBoxLayout(self.scrollAreaContents)
        self.verticalLayout_10.setSpacing(0)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.verticalLayout_10.setContentsMargins(0, -1, 0, -1)
        self.verticalSpacer_2 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_10.addItem(self.verticalSpacer_2)

        self.scrollArea.setWidget(self.scrollAreaContents)

        self.verticalLayout_5.addWidget(self.scrollArea)


        self.verticalLayout_3.addWidget(self.f_shear_dawn)


        self.horizontalLayout_4.addWidget(self.f_pag4_shear)

        self.stackedWidget.addWidget(self.pag_1)
        self.pag_2 = QWidget()
        self.pag_2.setObjectName(u"pag_2")
        self.horizontalLayout_16 = QHBoxLayout(self.pag_2)
        self.horizontalLayout_16.setSpacing(0)
        self.horizontalLayout_16.setObjectName(u"horizontalLayout_16")
        self.horizontalLayout_16.setContentsMargins(0, 0, 0, 0)
        self.f_pag5_perfil = QFrame(self.pag_2)
        self.f_pag5_perfil.setObjectName(u"f_pag5_perfil")
        self.f_pag5_perfil.setFrameShape(QFrame.Shape.NoFrame)
        self.f_pag5_perfil.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_17 = QHBoxLayout(self.f_pag5_perfil)
        self.horizontalLayout_17.setObjectName(u"horizontalLayout_17")
        self.f_marco_perfil = QFrame(self.f_pag5_perfil)
        self.f_marco_perfil.setObjectName(u"f_marco_perfil")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Ignored)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.f_marco_perfil.sizePolicy().hasHeightForWidth())
        self.f_marco_perfil.setSizePolicy(sizePolicy2)
        self.f_marco_perfil.setMinimumSize(QSize(500, 300))
        self.f_marco_perfil.setMaximumSize(QSize(1000, 500))
        self.f_marco_perfil.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_marco_perfil.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_15 = QVBoxLayout(self.f_marco_perfil)
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")
        self.f_distribucuin_perfil = QFrame(self.f_marco_perfil)
        self.f_distribucuin_perfil.setObjectName(u"f_distribucuin_perfil")
        self.f_distribucuin_perfil.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_distribucuin_perfil.setFrameShadow(QFrame.Shadow.Raised)
        self.gridLayout = QGridLayout(self.f_distribucuin_perfil)
        self.gridLayout.setObjectName(u"gridLayout")
        self.label_img = QLabel(self.f_distribucuin_perfil)
        self.label_img.setObjectName(u"label_img")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.label_img.sizePolicy().hasHeightForWidth())
        self.label_img.setSizePolicy(sizePolicy3)
        self.label_img.setMinimumSize(QSize(130, 130))

        self.gridLayout.addWidget(self.label_img, 0, 0, 1, 1, Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignVCenter)

        self.f_nick = QFrame(self.f_distribucuin_perfil)
        self.f_nick.setObjectName(u"f_nick")
        self.f_nick.setMinimumSize(QSize(130, 130))
        self.f_nick.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_nick.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_16 = QVBoxLayout(self.f_nick)
        self.verticalLayout_16.setObjectName(u"verticalLayout_16")
        self.label_nick = QLabel(self.f_nick)
        self.label_nick.setObjectName(u"label_nick")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.label_nick.sizePolicy().hasHeightForWidth())
        self.label_nick.setSizePolicy(sizePolicy4)

        self.verticalLayout_16.addWidget(self.label_nick, 0, Qt.AlignmentFlag.AlignVCenter)


        self.gridLayout.addWidget(self.f_nick, 0, 1, 1, 1, Qt.AlignmentFlag.AlignVCenter)

        self.f_datos = QFrame(self.f_distribucuin_perfil)
        self.f_datos.setObjectName(u"f_datos")
        self.f_datos.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_datos.setFrameShadow(QFrame.Shadow.Raised)
        self.gridLayout_2 = QGridLayout(self.f_datos)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.label_nombre1 = QLabel(self.f_datos)
        self.label_nombre1.setObjectName(u"label_nombre1")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy5.setHorizontalStretch(0)
        sizePolicy5.setVerticalStretch(0)
        sizePolicy5.setHeightForWidth(self.label_nombre1.sizePolicy().hasHeightForWidth())
        self.label_nombre1.setSizePolicy(sizePolicy5)

        self.gridLayout_2.addWidget(self.label_nombre1, 0, 0, 1, 1)

        self.label_nombre2 = QLabel(self.f_datos)
        self.label_nombre2.setObjectName(u"label_nombre2")
        sizePolicy5.setHeightForWidth(self.label_nombre2.sizePolicy().hasHeightForWidth())
        self.label_nombre2.setSizePolicy(sizePolicy5)

        self.gridLayout_2.addWidget(self.label_nombre2, 0, 1, 1, 1)

        self.label_apellido1 = QLabel(self.f_datos)
        self.label_apellido1.setObjectName(u"label_apellido1")

        self.gridLayout_2.addWidget(self.label_apellido1, 1, 0, 1, 1)

        self.label_apellido2 = QLabel(self.f_datos)
        self.label_apellido2.setObjectName(u"label_apellido2")

        self.gridLayout_2.addWidget(self.label_apellido2, 1, 1, 1, 1)

        self.label_padsword = QLabel(self.f_datos)
        self.label_padsword.setObjectName(u"label_padsword")

        self.gridLayout_2.addWidget(self.label_padsword, 2, 0, 1, 1)

        self.lineedit_password = QLineEdit(self.f_datos)
        self.lineedit_password.setObjectName(u"lineedit_password")
        sizePolicy1.setHeightForWidth(self.lineedit_password.sizePolicy().hasHeightForWidth())
        self.lineedit_password.setSizePolicy(sizePolicy1)
        self.lineedit_password.setEchoMode(QLineEdit.EchoMode.Password)
        self.lineedit_password.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.lineedit_password.setDragEnabled(False)
        self.lineedit_password.setReadOnly(True)
        self.lineedit_password.setPlaceholderText(u"")
        self.lineedit_password.setClearButtonEnabled(False)

        self.gridLayout_2.addWidget(self.lineedit_password, 2, 1, 1, 1)


        self.gridLayout.addWidget(self.f_datos, 1, 0, 1, 2)


        self.verticalLayout_15.addWidget(self.f_distribucuin_perfil)

        self.frame = QFrame(self.f_marco_perfil)
        self.frame.setObjectName(u"frame")
        sizePolicy1.setHeightForWidth(self.frame.sizePolicy().hasHeightForWidth())
        self.frame.setSizePolicy(sizePolicy1)
        self.frame.setMinimumSize(QSize(0, 50))
        self.frame.setMaximumSize(QSize(16777215, 50))
        self.frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_24 = QHBoxLayout(self.frame)
        self.horizontalLayout_24.setObjectName(u"horizontalLayout_24")
        self.b_ver_password = QPushButton(self.frame)
        self.b_ver_password.setObjectName(u"b_ver_password")
        self.b_ver_password.setCheckable(True)
        self.b_ver_password.setChecked(False)
        self.b_ver_password.setAutoRepeat(False)

        self.horizontalLayout_24.addWidget(self.b_ver_password)

        self.b_cambiar_pasworld = QPushButton(self.frame)
        self.b_cambiar_pasworld.setObjectName(u"b_cambiar_pasworld")

        self.horizontalLayout_24.addWidget(self.b_cambiar_pasworld)


        self.verticalLayout_15.addWidget(self.frame)


        self.horizontalLayout_17.addWidget(self.f_marco_perfil)


        self.horizontalLayout_16.addWidget(self.f_pag5_perfil)

        self.stackedWidget.addWidget(self.pag_2)
        self.pag_3 = QWidget()
        self.pag_3.setObjectName(u"pag_3")
        self.horizontalLayout_9 = QHBoxLayout(self.pag_3)
        self.horizontalLayout_9.setSpacing(0)
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.horizontalLayout_9.setContentsMargins(0, 0, 0, 0)
        self.f_pag3_config = QFrame(self.pag_3)
        self.f_pag3_config.setObjectName(u"f_pag3_config")
        self.f_pag3_config.setFrameShape(QFrame.Shape.NoFrame)
        self.f_pag3_config.setFrameShadow(QFrame.Shadow.Raised)
        self.label_4 = QLabel(self.f_pag3_config)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(40, 210, 691, 361))
        self.label_4.setMinimumSize(QSize(32, 32))
        self.label_4.setPixmap(QPixmap(u"../VS Code/PROYECTO QT PY/APP/images/images/ugma.png"))

        self.horizontalLayout_9.addWidget(self.f_pag3_config)

        self.stackedWidget.addWidget(self.pag_3)
        self.pag_4 = QWidget()
        self.pag_4.setObjectName(u"pag_4")
        sizePolicy6 = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Maximum)
        sizePolicy6.setHorizontalStretch(0)
        sizePolicy6.setVerticalStretch(0)
        sizePolicy6.setHeightForWidth(self.pag_4.sizePolicy().hasHeightForWidth())
        self.pag_4.setSizePolicy(sizePolicy6)
        self.horizontalLayout_7 = QHBoxLayout(self.pag_4)
        self.horizontalLayout_7.setSpacing(0)
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.horizontalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.f_pag2_stats = QFrame(self.pag_4)
        self.f_pag2_stats.setObjectName(u"f_pag2_stats")
        self.f_pag2_stats.setFrameShape(QFrame.Shape.NoFrame)
        self.f_pag2_stats.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_13 = QHBoxLayout(self.f_pag2_stats)
        self.horizontalLayout_13.setObjectName(u"horizontalLayout_13")
        self.tabWidget = QTabWidget(self.f_pag2_stats)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setTabsClosable(True)

        self.horizontalLayout_13.addWidget(self.tabWidget)


        self.horizontalLayout_7.addWidget(self.f_pag2_stats)

        self.stackedWidget.addWidget(self.pag_4)
        self.pag_5 = QWidget()
        self.pag_5.setObjectName(u"pag_5")
        self.horizontalLayout_8 = QHBoxLayout(self.pag_5)
        self.horizontalLayout_8.setSpacing(0)
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.horizontalLayout_8.setContentsMargins(0, 0, 0, 0)
        self.f_pag1_encuesta = QFrame(self.pag_5)
        self.f_pag1_encuesta.setObjectName(u"f_pag1_encuesta")
        self.f_pag1_encuesta.setFrameShape(QFrame.Shape.NoFrame)
        self.f_pag1_encuesta.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_12 = QHBoxLayout(self.f_pag1_encuesta)
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.stackedWidget_2 = QStackedWidget(self.f_pag1_encuesta)
        self.stackedWidget_2.setObjectName(u"stackedWidget_2")
        self.e_pag_0 = QWidget()
        self.e_pag_0.setObjectName(u"e_pag_0")
        self.verticalLayout_9 = QVBoxLayout(self.e_pag_0)
        self.verticalLayout_9.setSpacing(0)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.verticalLayout_9.setContentsMargins(0, 0, 0, 0)
        self.f_epage0_dawn = QFrame(self.e_pag_0)
        self.f_epage0_dawn.setObjectName(u"f_epage0_dawn")
        self.f_epage0_dawn.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_epage0_dawn.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_15 = QHBoxLayout(self.f_epage0_dawn)
        self.horizontalLayout_15.setObjectName(u"horizontalLayout_15")
        self.b_edit_encuesta = QPushButton(self.f_epage0_dawn)
        self.b_edit_encuesta.setObjectName(u"b_edit_encuesta")
        sizePolicy7 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        sizePolicy7.setHorizontalStretch(0)
        sizePolicy7.setVerticalStretch(0)
        sizePolicy7.setHeightForWidth(self.b_edit_encuesta.sizePolicy().hasHeightForWidth())
        self.b_edit_encuesta.setSizePolicy(sizePolicy7)
        self.b_edit_encuesta.setStyleSheet(u"QPushButton{\n"
"}")
        self.b_edit_encuesta.setCheckable(False)

        self.horizontalLayout_15.addWidget(self.b_edit_encuesta)

        self.b_enviar_encuesta = QPushButton(self.f_epage0_dawn)
        self.b_enviar_encuesta.setObjectName(u"b_enviar_encuesta")
        sizePolicy7.setHeightForWidth(self.b_enviar_encuesta.sizePolicy().hasHeightForWidth())
        self.b_enviar_encuesta.setSizePolicy(sizePolicy7)
        self.b_enviar_encuesta.setCheckable(False)

        self.horizontalLayout_15.addWidget(self.b_enviar_encuesta)


        self.verticalLayout_9.addWidget(self.f_epage0_dawn)

        self.stackedWidget_2.addWidget(self.e_pag_0)
        self.e_pag_1 = QWidget()
        self.e_pag_1.setObjectName(u"e_pag_1")
        self.verticalLayout_7 = QVBoxLayout(self.e_pag_1)
        self.verticalLayout_7.setSpacing(0)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.verticalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.f_edit_barr = QFrame(self.e_pag_1)
        self.f_edit_barr.setObjectName(u"f_edit_barr")
        self.f_edit_barr.setMinimumSize(QSize(0, 35))
        self.f_edit_barr.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_edit_barr.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_18 = QHBoxLayout(self.f_edit_barr)
        self.horizontalLayout_18.setSpacing(0)
        self.horizontalLayout_18.setObjectName(u"horizontalLayout_18")
        self.horizontalLayout_18.setContentsMargins(0, 0, 0, 0)
        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_18.addItem(self.horizontalSpacer)

        self.b_atras_encuesta = QPushButton(self.f_edit_barr)
        self.b_atras_encuesta.setObjectName(u"b_atras_encuesta")
        self.b_atras_encuesta.setMinimumSize(QSize(35, 0))

        self.horizontalLayout_18.addWidget(self.b_atras_encuesta)

        self.b_cancelar_encuesta = QPushButton(self.f_edit_barr)
        self.b_cancelar_encuesta.setObjectName(u"b_cancelar_encuesta")
        self.b_cancelar_encuesta.setMinimumSize(QSize(35, 0))

        self.horizontalLayout_18.addWidget(self.b_cancelar_encuesta)

        self.b_guardar_encuesta = QPushButton(self.f_edit_barr)
        self.b_guardar_encuesta.setObjectName(u"b_guardar_encuesta")
        self.b_guardar_encuesta.setMinimumSize(QSize(35, 0))

        self.horizontalLayout_18.addWidget(self.b_guardar_encuesta)


        self.verticalLayout_7.addWidget(self.f_edit_barr)

        self.f_edit_up = QFrame(self.e_pag_1)
        self.f_edit_up.setObjectName(u"f_edit_up")
        self.f_edit_up.setMinimumSize(QSize(0, 60))
        self.f_edit_up.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_edit_up.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_19 = QHBoxLayout(self.f_edit_up)
        self.horizontalLayout_19.setSpacing(15)
        self.horizontalLayout_19.setObjectName(u"horizontalLayout_19")
        self.horizontalLayout_19.setContentsMargins(15, 0, 15, 0)
        self.b_categoria_1 = QPushButton(self.f_edit_up)
        self.b_categoria_1.setObjectName(u"b_categoria_1")
        self.b_categoria_1.setCheckable(True)
        self.b_categoria_1.setChecked(True)
        self.b_categoria_1.setAutoExclusive(True)

        self.horizontalLayout_19.addWidget(self.b_categoria_1)

        self.b_categoria_2 = QPushButton(self.f_edit_up)
        self.b_categoria_2.setObjectName(u"b_categoria_2")
        self.b_categoria_2.setCheckable(True)
        self.b_categoria_2.setAutoExclusive(True)

        self.horizontalLayout_19.addWidget(self.b_categoria_2)

        self.b_categoria_3 = QPushButton(self.f_edit_up)
        self.b_categoria_3.setObjectName(u"b_categoria_3")
        self.b_categoria_3.setCheckable(True)
        self.b_categoria_3.setAutoExclusive(True)

        self.horizontalLayout_19.addWidget(self.b_categoria_3)

        self.b_categoria_4 = QPushButton(self.f_edit_up)
        self.b_categoria_4.setObjectName(u"b_categoria_4")
        self.b_categoria_4.setCheckable(True)
        self.b_categoria_4.setAutoExclusive(True)

        self.horizontalLayout_19.addWidget(self.b_categoria_4)


        self.verticalLayout_7.addWidget(self.f_edit_up)

        self.f_edit_dawn = QFrame(self.e_pag_1)
        self.f_edit_dawn.setObjectName(u"f_edit_dawn")
        self.f_edit_dawn.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_edit_dawn.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_14 = QHBoxLayout(self.f_edit_dawn)
        self.horizontalLayout_14.setObjectName(u"horizontalLayout_14")
        self.stackedWidget_3 = QStackedWidget(self.f_edit_dawn)
        self.stackedWidget_3.setObjectName(u"stackedWidget_3")
        self.pregunta_pag1 = QWidget()
        self.pregunta_pag1.setObjectName(u"pregunta_pag1")
        self.horizontalLayout_20 = QHBoxLayout(self.pregunta_pag1)
        self.horizontalLayout_20.setSpacing(0)
        self.horizontalLayout_20.setObjectName(u"horizontalLayout_20")
        self.horizontalLayout_20.setContentsMargins(0, 0, 0, 0)
        self.f_cat1 = QFrame(self.pregunta_pag1)
        self.f_cat1.setObjectName(u"f_cat1")
        self.f_cat1.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_cat1.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_8 = QVBoxLayout(self.f_cat1)
        self.verticalLayout_8.setSpacing(0)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.verticalLayout_8.setContentsMargins(0, 0, 0, 0)
        self.l_pregunta1_11 = QLabel(self.f_cat1)
        self.l_pregunta1_11.setObjectName(u"l_pregunta1_11")
        sizePolicy8 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Minimum)
        sizePolicy8.setHorizontalStretch(0)
        sizePolicy8.setVerticalStretch(0)
        sizePolicy8.setHeightForWidth(self.l_pregunta1_11.sizePolicy().hasHeightForWidth())
        self.l_pregunta1_11.setSizePolicy(sizePolicy8)
        self.l_pregunta1_11.setMinimumSize(QSize(0, 30))

        self.verticalLayout_8.addWidget(self.l_pregunta1_11)

        self.lineedit_preg1_11 = QLineEdit(self.f_cat1)
        self.lineedit_preg1_11.setObjectName(u"lineedit_preg1_11")
        self.lineedit_preg1_11.setMinimumSize(QSize(0, 30))

        self.verticalLayout_8.addWidget(self.lineedit_preg1_11)

        self.l_pregunta2_11 = QLabel(self.f_cat1)
        self.l_pregunta2_11.setObjectName(u"l_pregunta2_11")
        self.l_pregunta2_11.setMinimumSize(QSize(0, 30))

        self.verticalLayout_8.addWidget(self.l_pregunta2_11)

        self.lineedit_preg2_11 = QLineEdit(self.f_cat1)
        self.lineedit_preg2_11.setObjectName(u"lineedit_preg2_11")
        self.lineedit_preg2_11.setMinimumSize(QSize(0, 30))

        self.verticalLayout_8.addWidget(self.lineedit_preg2_11)

        self.l_pregunta3_11 = QLabel(self.f_cat1)
        self.l_pregunta3_11.setObjectName(u"l_pregunta3_11")
        self.l_pregunta3_11.setMinimumSize(QSize(0, 30))

        self.verticalLayout_8.addWidget(self.l_pregunta3_11)

        self.lineedit_preg3_11 = QLineEdit(self.f_cat1)
        self.lineedit_preg3_11.setObjectName(u"lineedit_preg3_11")
        self.lineedit_preg3_11.setMinimumSize(QSize(0, 30))

        self.verticalLayout_8.addWidget(self.lineedit_preg3_11)

        self.l_pregunta4_11 = QLabel(self.f_cat1)
        self.l_pregunta4_11.setObjectName(u"l_pregunta4_11")
        self.l_pregunta4_11.setMinimumSize(QSize(0, 30))

        self.verticalLayout_8.addWidget(self.l_pregunta4_11)

        self.lineedit_preg4_11 = QLineEdit(self.f_cat1)
        self.lineedit_preg4_11.setObjectName(u"lineedit_preg4_11")
        self.lineedit_preg4_11.setMinimumSize(QSize(0, 30))

        self.verticalLayout_8.addWidget(self.lineedit_preg4_11)

        self.verticalSpacer_3 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_8.addItem(self.verticalSpacer_3)


        self.horizontalLayout_20.addWidget(self.f_cat1)

        self.stackedWidget_3.addWidget(self.pregunta_pag1)
        self.pregunta_pag2 = QWidget()
        self.pregunta_pag2.setObjectName(u"pregunta_pag2")
        self.horizontalLayout_21 = QHBoxLayout(self.pregunta_pag2)
        self.horizontalLayout_21.setSpacing(0)
        self.horizontalLayout_21.setObjectName(u"horizontalLayout_21")
        self.horizontalLayout_21.setContentsMargins(0, 0, 0, 0)
        self.f_cat2 = QFrame(self.pregunta_pag2)
        self.f_cat2.setObjectName(u"f_cat2")
        self.f_cat2.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_cat2.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_12 = QVBoxLayout(self.f_cat2)
        self.verticalLayout_12.setSpacing(0)
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.verticalLayout_12.setContentsMargins(0, 0, 0, 0)
        self.l_pregunta1_22 = QLabel(self.f_cat2)
        self.l_pregunta1_22.setObjectName(u"l_pregunta1_22")
        sizePolicy8.setHeightForWidth(self.l_pregunta1_22.sizePolicy().hasHeightForWidth())
        self.l_pregunta1_22.setSizePolicy(sizePolicy8)
        self.l_pregunta1_22.setMinimumSize(QSize(0, 30))

        self.verticalLayout_12.addWidget(self.l_pregunta1_22)

        self.lineedit_preg1_22 = QLineEdit(self.f_cat2)
        self.lineedit_preg1_22.setObjectName(u"lineedit_preg1_22")
        self.lineedit_preg1_22.setMinimumSize(QSize(0, 30))

        self.verticalLayout_12.addWidget(self.lineedit_preg1_22)

        self.l_pregunta2_22 = QLabel(self.f_cat2)
        self.l_pregunta2_22.setObjectName(u"l_pregunta2_22")
        self.l_pregunta2_22.setMinimumSize(QSize(0, 30))

        self.verticalLayout_12.addWidget(self.l_pregunta2_22)

        self.lineedit_preg2_22 = QLineEdit(self.f_cat2)
        self.lineedit_preg2_22.setObjectName(u"lineedit_preg2_22")
        self.lineedit_preg2_22.setMinimumSize(QSize(0, 30))

        self.verticalLayout_12.addWidget(self.lineedit_preg2_22)

        self.l_pregunta3_22 = QLabel(self.f_cat2)
        self.l_pregunta3_22.setObjectName(u"l_pregunta3_22")
        self.l_pregunta3_22.setMinimumSize(QSize(0, 30))

        self.verticalLayout_12.addWidget(self.l_pregunta3_22)

        self.lineedit_preg3_22 = QLineEdit(self.f_cat2)
        self.lineedit_preg3_22.setObjectName(u"lineedit_preg3_22")
        self.lineedit_preg3_22.setMinimumSize(QSize(0, 30))

        self.verticalLayout_12.addWidget(self.lineedit_preg3_22)

        self.l_pregunta4_22 = QLabel(self.f_cat2)
        self.l_pregunta4_22.setObjectName(u"l_pregunta4_22")
        self.l_pregunta4_22.setMinimumSize(QSize(0, 30))

        self.verticalLayout_12.addWidget(self.l_pregunta4_22)

        self.lineedit_preg4_22 = QLineEdit(self.f_cat2)
        self.lineedit_preg4_22.setObjectName(u"lineedit_preg4_22")
        self.lineedit_preg4_22.setMinimumSize(QSize(0, 30))

        self.verticalLayout_12.addWidget(self.lineedit_preg4_22)

        self.verticalSpacer_5 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_12.addItem(self.verticalSpacer_5)


        self.horizontalLayout_21.addWidget(self.f_cat2)

        self.stackedWidget_3.addWidget(self.pregunta_pag2)
        self.pregunta_pag4 = QWidget()
        self.pregunta_pag4.setObjectName(u"pregunta_pag4")
        self.horizontalLayout_23 = QHBoxLayout(self.pregunta_pag4)
        self.horizontalLayout_23.setSpacing(0)
        self.horizontalLayout_23.setObjectName(u"horizontalLayout_23")
        self.horizontalLayout_23.setContentsMargins(0, 0, 0, 0)
        self.f_cat4 = QFrame(self.pregunta_pag4)
        self.f_cat4.setObjectName(u"f_cat4")
        self.f_cat4.setFrameShape(QFrame.Shape.NoFrame)
        self.f_cat4.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_14 = QVBoxLayout(self.f_cat4)
        self.verticalLayout_14.setSpacing(0)
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.verticalLayout_14.setContentsMargins(0, 0, 0, 0)
        self.l_pregunta1_44 = QLabel(self.f_cat4)
        self.l_pregunta1_44.setObjectName(u"l_pregunta1_44")
        sizePolicy8.setHeightForWidth(self.l_pregunta1_44.sizePolicy().hasHeightForWidth())
        self.l_pregunta1_44.setSizePolicy(sizePolicy8)
        self.l_pregunta1_44.setMinimumSize(QSize(0, 30))

        self.verticalLayout_14.addWidget(self.l_pregunta1_44)

        self.lineedit_preg1_44 = QLineEdit(self.f_cat4)
        self.lineedit_preg1_44.setObjectName(u"lineedit_preg1_44")
        self.lineedit_preg1_44.setMinimumSize(QSize(0, 30))

        self.verticalLayout_14.addWidget(self.lineedit_preg1_44)

        self.l_pregunta2_44 = QLabel(self.f_cat4)
        self.l_pregunta2_44.setObjectName(u"l_pregunta2_44")
        self.l_pregunta2_44.setMinimumSize(QSize(0, 30))

        self.verticalLayout_14.addWidget(self.l_pregunta2_44)

        self.lineedit_preg2_44 = QLineEdit(self.f_cat4)
        self.lineedit_preg2_44.setObjectName(u"lineedit_preg2_44")
        self.lineedit_preg2_44.setMinimumSize(QSize(0, 30))

        self.verticalLayout_14.addWidget(self.lineedit_preg2_44)

        self.l_pregunta3_44 = QLabel(self.f_cat4)
        self.l_pregunta3_44.setObjectName(u"l_pregunta3_44")
        self.l_pregunta3_44.setMinimumSize(QSize(0, 30))

        self.verticalLayout_14.addWidget(self.l_pregunta3_44)

        self.lineedit_preg3_44 = QLineEdit(self.f_cat4)
        self.lineedit_preg3_44.setObjectName(u"lineedit_preg3_44")
        self.lineedit_preg3_44.setMinimumSize(QSize(0, 30))

        self.verticalLayout_14.addWidget(self.lineedit_preg3_44)

        self.l_pregunta4_44 = QLabel(self.f_cat4)
        self.l_pregunta4_44.setObjectName(u"l_pregunta4_44")
        self.l_pregunta4_44.setMinimumSize(QSize(0, 30))

        self.verticalLayout_14.addWidget(self.l_pregunta4_44)

        self.lineedit_preg4_44 = QLineEdit(self.f_cat4)
        self.lineedit_preg4_44.setObjectName(u"lineedit_preg4_44")
        self.lineedit_preg4_44.setMinimumSize(QSize(0, 30))

        self.verticalLayout_14.addWidget(self.lineedit_preg4_44)

        self.verticalSpacer_7 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_14.addItem(self.verticalSpacer_7)


        self.horizontalLayout_23.addWidget(self.f_cat4)

        self.stackedWidget_3.addWidget(self.pregunta_pag4)
        self.pregunta_pag3 = QWidget()
        self.pregunta_pag3.setObjectName(u"pregunta_pag3")
        self.horizontalLayout_22 = QHBoxLayout(self.pregunta_pag3)
        self.horizontalLayout_22.setSpacing(0)
        self.horizontalLayout_22.setObjectName(u"horizontalLayout_22")
        self.horizontalLayout_22.setContentsMargins(0, 0, 0, 0)
        self.f_cat3 = QFrame(self.pregunta_pag3)
        self.f_cat3.setObjectName(u"f_cat3")
        self.f_cat3.setFrameShape(QFrame.Shape.StyledPanel)
        self.f_cat3.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_13 = QVBoxLayout(self.f_cat3)
        self.verticalLayout_13.setSpacing(0)
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.verticalLayout_13.setContentsMargins(0, 0, 0, 0)
        self.l_pregunta1_33 = QLabel(self.f_cat3)
        self.l_pregunta1_33.setObjectName(u"l_pregunta1_33")
        sizePolicy8.setHeightForWidth(self.l_pregunta1_33.sizePolicy().hasHeightForWidth())
        self.l_pregunta1_33.setSizePolicy(sizePolicy8)
        self.l_pregunta1_33.setMinimumSize(QSize(0, 30))

        self.verticalLayout_13.addWidget(self.l_pregunta1_33)

        self.lineedit_preg1_33 = QLineEdit(self.f_cat3)
        self.lineedit_preg1_33.setObjectName(u"lineedit_preg1_33")
        self.lineedit_preg1_33.setMinimumSize(QSize(0, 30))

        self.verticalLayout_13.addWidget(self.lineedit_preg1_33)

        self.l_pregunta2_33 = QLabel(self.f_cat3)
        self.l_pregunta2_33.setObjectName(u"l_pregunta2_33")
        self.l_pregunta2_33.setMinimumSize(QSize(0, 30))

        self.verticalLayout_13.addWidget(self.l_pregunta2_33)

        self.lineedit_preg2_33 = QLineEdit(self.f_cat3)
        self.lineedit_preg2_33.setObjectName(u"lineedit_preg2_33")
        self.lineedit_preg2_33.setMinimumSize(QSize(0, 30))

        self.verticalLayout_13.addWidget(self.lineedit_preg2_33)

        self.l_pregunta3_33 = QLabel(self.f_cat3)
        self.l_pregunta3_33.setObjectName(u"l_pregunta3_33")
        self.l_pregunta3_33.setMinimumSize(QSize(0, 30))

        self.verticalLayout_13.addWidget(self.l_pregunta3_33)

        self.lineedit_preg3_33 = QLineEdit(self.f_cat3)
        self.lineedit_preg3_33.setObjectName(u"lineedit_preg3_33")
        self.lineedit_preg3_33.setMinimumSize(QSize(0, 30))

        self.verticalLayout_13.addWidget(self.lineedit_preg3_33)

        self.l_pregunta4_33 = QLabel(self.f_cat3)
        self.l_pregunta4_33.setObjectName(u"l_pregunta4_33")
        self.l_pregunta4_33.setMinimumSize(QSize(0, 30))

        self.verticalLayout_13.addWidget(self.l_pregunta4_33)

        self.lineedit_preg4_33 = QLineEdit(self.f_cat3)
        self.lineedit_preg4_33.setObjectName(u"lineedit_preg4_33")
        self.lineedit_preg4_33.setMinimumSize(QSize(0, 30))

        self.verticalLayout_13.addWidget(self.lineedit_preg4_33)

        self.verticalSpacer_6 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_13.addItem(self.verticalSpacer_6)


        self.horizontalLayout_22.addWidget(self.f_cat3)

        self.stackedWidget_3.addWidget(self.pregunta_pag3)

        self.horizontalLayout_14.addWidget(self.stackedWidget_3)


        self.verticalLayout_7.addWidget(self.f_edit_dawn)

        self.stackedWidget_2.addWidget(self.e_pag_1)

        self.horizontalLayout_12.addWidget(self.stackedWidget_2)


        self.horizontalLayout_8.addWidget(self.f_pag1_encuesta)

        self.stackedWidget.addWidget(self.pag_5)

        self.verticalLayout_4.addWidget(self.stackedWidget)


        self.horizontalLayout_2.addWidget(self.f_ventanas)


        self.verticalLayout.addWidget(self.f_cuerpo_dawn)

        MainWindow.setCentralWidget(self.w_central)

        self.retranslateUi(MainWindow)

        self.stackedWidget.setCurrentIndex(0)
        self.tabWidget.setCurrentIndex(-1)
        self.stackedWidget_2.setCurrentIndex(1)
        self.stackedWidget_3.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.b_logo.setText("")
        self.b_perfil.setText("")
        self.b_encuesta.setText("")
        self.b_stats.setText("")
        self.b_config.setText("")
        self.label.setText("")
        self.lineEdit.setText(QCoreApplication.translate("MainWindow", u"....", None))
        self.label_img.setText(QCoreApplication.translate("MainWindow", u"IMG PERFIL", None))
        self.label_nick.setText(QCoreApplication.translate("MainWindow", u"NICK", None))
        self.label_nombre1.setText(QCoreApplication.translate("MainWindow", u"NOMBRE 1", None))
        self.label_nombre2.setText(QCoreApplication.translate("MainWindow", u"NOMBRE 2", None))
        self.label_apellido1.setText(QCoreApplication.translate("MainWindow", u"APELLIDO 1", None))
        self.label_apellido2.setText(QCoreApplication.translate("MainWindow", u"APELLIDO 2", None))
        self.label_padsword.setText(QCoreApplication.translate("MainWindow", u"CONTRASE;A", None))
        self.lineedit_password.setText(QCoreApplication.translate("MainWindow", u"1234", None))
        self.b_ver_password.setText(QCoreApplication.translate("MainWindow", u"VER CONTRASE;A", None))
        self.b_cambiar_pasworld.setText(QCoreApplication.translate("MainWindow", u"CAMBIAR CONTRASE;A", None))
        self.label_4.setText("")
        self.b_edit_encuesta.setText(QCoreApplication.translate("MainWindow", u"EDITAR ENCUESTAS", None))
        self.b_enviar_encuesta.setText(QCoreApplication.translate("MainWindow", u"ENVIAR ENCUESTAS", None))
        self.b_atras_encuesta.setText("")
        self.b_cancelar_encuesta.setText("")
        self.b_guardar_encuesta.setText("")
        self.b_categoria_1.setText(QCoreApplication.translate("MainWindow", u"cat 1", None))
        self.b_categoria_2.setText(QCoreApplication.translate("MainWindow", u"cat2", None))
        self.b_categoria_3.setText(QCoreApplication.translate("MainWindow", u"cat 3", None))
        self.b_categoria_4.setText(QCoreApplication.translate("MainWindow", u"cat 4", None))
        self.l_pregunta1_11.setText(QCoreApplication.translate("MainWindow", u"Pregunta 1", None))
        self.lineedit_preg1_11.setText("")
        self.l_pregunta2_11.setText(QCoreApplication.translate("MainWindow", u"Pregunta 2", None))
        self.l_pregunta3_11.setText(QCoreApplication.translate("MainWindow", u"Pregunta 3", None))
        self.l_pregunta4_11.setText(QCoreApplication.translate("MainWindow", u"Pregunta 4", None))
        self.l_pregunta1_22.setText(QCoreApplication.translate("MainWindow", u"Pregunta 1", None))
        self.lineedit_preg1_22.setText("")
        self.l_pregunta2_22.setText(QCoreApplication.translate("MainWindow", u"Pregunta 2", None))
        self.l_pregunta3_22.setText(QCoreApplication.translate("MainWindow", u"Pregunta 3", None))
        self.l_pregunta4_22.setText(QCoreApplication.translate("MainWindow", u"Pregunta 4", None))
        self.l_pregunta1_44.setText(QCoreApplication.translate("MainWindow", u"Pregunta 1", None))
        self.lineedit_preg1_44.setText("")
        self.l_pregunta2_44.setText(QCoreApplication.translate("MainWindow", u"Pregunta 2", None))
        self.l_pregunta3_44.setText(QCoreApplication.translate("MainWindow", u"Pregunta 3", None))
        self.l_pregunta4_44.setText(QCoreApplication.translate("MainWindow", u"Pregunta 4", None))
        self.l_pregunta1_33.setText(QCoreApplication.translate("MainWindow", u"Pregunta 1", None))
        self.lineedit_preg1_33.setText("")
        self.l_pregunta2_33.setText(QCoreApplication.translate("MainWindow", u"Pregunta 2", None))
        self.l_pregunta3_33.setText(QCoreApplication.translate("MainWindow", u"Pregunta 3", None))
        self.l_pregunta4_33.setText(QCoreApplication.translate("MainWindow", u"Pregunta 4", None))
    # retranslateUi

