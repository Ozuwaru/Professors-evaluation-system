from PySide6.QtWidgets import QApplication, QMainWindow, QFrame, QWidget, QLineEdit
from ui_qt_form import Ui_MainWindow
from ui_qt_login import Ui_Logni
from ui_qt_profe import Ui_f_profe
from funciones import *
from Bot_mail import *

# from ui_user import Ui_Frame

class App(QMainWindow):
    def __init__(self):
        super(App, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        
        # CONECCIONES DEL MENU PRINCIPAL
        self.ui.b_logo.clicked.connect(self.mostrarPaginaInicio)
        self.ui.b_perfil.clicked.connect(self.mostrarPaginaPerfil)
        self.ui.b_encuesta.toggled.connect(self.mostrarPaginaEncuesta)
        self.ui.b_stats.toggled.connect(self.mostrarPaginaEstadisticas)
        self.ui.b_shear.toggled.connect(self.mostrarPaginaBusqueda)
        self.ui.b_config.toggled.connect(self.mostrarPaginaConfiguracion)
        
        # CONECCIONES DE ENCUESTAS
        self.ui.b_enviar_encuesta.clicked.connect(self.activarBot)
        self.ui.b_edit_encuesta.clicked.connect(self.mostrarPaginaEdicion)
        
        self.ui.b_atras_encuesta.clicked.connect(self.devolverPaginaEditar)
        self.ui.b_guardar_encuesta.clicked.connect(self.gurardarEdicion)
        self.ui.b_cancelar_encuesta.clicked.connect(self.cancelarEdicion)
        
        self.ui.b_categoria_1.toggled.connect(self.mostrarCatergoria_1)
        self.ui.b_categoria_2.toggled.connect(self.mostrarCatergoria_2)
        self.ui.b_categoria_3.toggled.connect(self.mostrarCatergoria_3)
        self.ui.b_categoria_4.toggled.connect(self.mostrarCatergoria_4)
        
        # CONECCIONES DE BUSQUEDA
        self.ui.b_shear_2.clicked.connect(self.resultadoBusqueda)
        
        # CONECCIONES DE ESTADISTICAS
        self.ui.tabWidget.tabCloseRequested.connect(lambda index: self.ui.tabWidget.removeTab(index))
        
        # CONECCIONES DE PERFIL
        self.ui.b_ver_password.toggled.connect(self.verPassword)
        self.ui.tabWidget.tabCloseRequested.connect(lambda index: self.ui.tabWidget.removeTab(index))
            

    # FUNCIONES DE MENU
    def mostrarPaginaInicio(self):
        self.ui.stackedWidget.setCurrentIndex(0)
        
    def mostrarPaginaPerfil(self):
        self.ui.stackedWidget.setCurrentIndex(2)
   
    def mostrarPaginaEncuesta(self, checked):
        if checked:
            self.ui.stackedWidget.setCurrentIndex(5)
            
    def mostrarPaginaBusqueda(self, checked):
        if checked:
            self.ui.stackedWidget.setCurrentIndex(1)
   
    def mostrarPaginaEstadisticas(self, checked):
        if checked:
            self.ui.stackedWidget.setCurrentIndex(4)

    def mostrarPaginaConfiguracion(self, checked):
        if checked:
            self.ui.stackedWidget.setCurrentIndex(3)
            
    # FUNCIONES DE ENCUESTAS
    def activarBot(self):
        # BOT
        print ('email')
        
    def mostrarPaginaEdicion(self):
        self.ui.stackedWidget_2.setCurrentIndex(1)
        
    # Botones superior
    def devolverPaginaEditar(self):
        self.ui.stackedWidget_2.setCurrentIndex(0)
        
    def cancelarEdicion(self):
        for i in range(self.ui.stackedWidget_3.count()):
            pagina = self.ui.stackedWidget_3.widget(i)
            for child in pagina.findChildren(QLineEdit):
                child.clear()
        print ('borrar')
    
    def gurardarEdicion(self):
        datos = []
        
        for i in range(self.ui.stackedWidget_3.count()):
            pagina = self.ui.stackedWidget_3.widget(i)
            for child in pagina.findChildren(QLineEdit):
                datos.append(child.text())
        
        print ('guardar')
        print (datos)
        return datos
    
    # Botones de ediciones
    def mostrarCatergoria_1(self, checked):
        if checked:
            self.ui.stackedWidget_3.setCurrentIndex(0)
            
    def mostrarCatergoria_2(self, checked):
        if checked:
            self.ui.stackedWidget_3.setCurrentIndex(1)
            
    def mostrarCatergoria_3(self, checked):
        if checked:
            self.ui.stackedWidget_3.setCurrentIndex(2)
            
    def mostrarCatergoria_4(self, checked):
        if checked:
            self.ui.stackedWidget_3.setCurrentIndex(3)
        
    
    # FUNCIONES DE ESTADISTICAS      
    def nuevaEstadisticas(self,id):
        f_aux_stat = Estadisticas(id)
        f_aux_stat.listaGraficas()
        self.ui.tabWidget.addTab(f_aux_stat,'+')
        
    # FUNCIONES DE BUSQUEDAS
    def resultadoBusqueda(self):
        search=self.ui.lineEdit.text()
        
        for i in reversed(range(self.ui.scrollAreaContents.layout().count())):
            widget = self.ui.scrollAreaContents.layout().itemAt(i).widget()
            if widget:
                widget.deleteLater()
        
        self.busqueda=Busqueda(self,search)
        lista=self.busqueda.recuadro()
        for i in range (len(lista)):
            self.ui.scrollAreaContents.layout().insertWidget(0, lista[i])
       
    # FUNCIONES DE PERFIL 
    def verPassword(self,checked):
        if checked:
            self.ui.lineedit_password.setEchoMode(QLineEdit.Normal)    
        else:
            self.ui.lineedit_password.setEchoMode(QLineEdit.Password)
   
     
class Estadisticas(QFrame):
    def __init__(self,idP):
        super(Estadisticas, self).__init__()
        self.ui = Ui_f_profe()
        self.ui.setupUi(self)
        self.id=idP
        self.informacion()
        # CONECCION DE LAS TAB EN AMBAS GRAFICAS
        self.ui.tab_graf_barra.currentChanged.connect(self.conectarGrafica)
        self.ui.tab_graf_linea.currentChanged.connect(self.conectarGrafica)
    
    # INICIALIZAION DE DATOS
    def informacion(self):
        datos=consultaId(self.id)
        self.ui.nombre_profe.setText(datos[0][1]+" - "+datos[0][3])
        self.ui.escuela_profe.setText(datos[0][2])
        # self.ui.perfil_profe.pixmap(img)
        self.ui.info_0.setText("Muy ineficiente: 1")
        self.ui.info_1.setText("Ineficiente: 2")
        self.ui.info_2.setText("Regular: 3")
        self.ui.info_3.setText("Eficiente: 4")
        self.ui.info_4.setText("Muy Eficiente: 5")
        
    # FUNCION DE CONEXION
    def conectarGrafica(self, indice):
        if self.sender() == self.ui.tab_graf_barra:
            self.ui.tab_graf_linea.setCurrentIndex(indice)
        elif self.sender() == self.ui.tab_graf_linea:
            self.ui.tab_graf_barra.setCurrentIndex(indice)
     
    def listaGraficas(self):
        cantM=tMaterias(self.id)
        self.tabGrafica(1,0)
        for i in range(len(cantM)):
            self.tabGrafica(0,cantM[i][0])
    
    def tabGrafica(self,graf,materia):
        tab_contein = GraphicTab(0,self.id,graf,materia)
        self.ui.tab_graf_barra.addTab(tab_contein, '+')

        tab_contein = GraphicTab(1,self.id,graf,materia)
        self.ui.tab_graf_linea.addTab(tab_contein, '+')
 
class Inicio(QWidget):
    def __init__(self):
        super(Inicio, self).__init__()
        self.ui = Ui_Logni()
        self.ui.setupUi(self)
        self.logeado = False
        
        self.ui.b_login.clicked.connect(self.logear)
        self.ui.b_register.clicked.connect(self.registrar)
        self.ui.b_volver.clicked.connect(self.volver)
        
    def logear(self):
        # LOGIN ANTES DE ABRIR LA APP
        self.logeado = True
        login.hide()
        window = App()
        window.show()
        pass
    
    def registrar(self):
        self.ui.stackedWidget.setCurrentIndex(1)
    
    def volver(self):
        self.ui.stackedWidget.setCurrentIndex(0)
    
if __name__ == "__main__":
    app = QApplication([])
    login = Inicio()
    login.show()
    app.exec()
    