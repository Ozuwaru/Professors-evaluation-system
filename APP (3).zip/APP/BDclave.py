
# CAMBIEN ESTAS VARIABLES: 
db_user = "root"
db_password = '17092001'

